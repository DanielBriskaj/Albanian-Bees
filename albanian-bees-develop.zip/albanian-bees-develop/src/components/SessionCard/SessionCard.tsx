import React from 'react';
import { SessionData } from '../../interfaces/Session';
import { useNavigate } from 'react-router';
import { ReactComponent as Calendar } from '../../assets/svgIcons/calendar-event.svg';
import { format, parseISO } from 'date-fns';
import { SessionStatusColor } from '../../helpers/sessionStatusColor';

export const SessionCard: React.FC<SessionData> = ({
  id,
  park,
  name,
  teamMember,
  createdAt,
  sessionStatus,
}) => {
  const navigate = useNavigate();

  const handleOpenSession = () => {
    navigate(`/sessions/${id}`);
  };

  const statusColor = SessionStatusColor(sessionStatus);

  return (
    <div className="session-card-container" onClick={handleOpenSession}>
      <section className="data">
        <section className="top-section">
          <div className="name">
            <div
              className="park-color"
              style={{
                background: park?.colorCode ? park?.colorCode : 'orange',
              }}
            ></div>
            <span>{name}</span>
          </div>
          <div
            className="status"
            style={{
              backgroundColor: statusColor?.bg,
              color: statusColor?.color,
            }}
          >
            {sessionStatus}
          </div>
        </section>

        <section className="bottom-section">
          <div className="first-part">
            <Calendar className="calendar" />{' '}
            {format(parseISO(createdAt), 'dd-MM-yyyy')}
          </div>
          <div className="members">
            {teamMember?.map((data, index) => {
              if (index <= 0) {
                return (
                  <span
                    key={index}
                    className="single-member"
                    title={data?.name + ' ' + data?.surname}
                  >
                    {data?.name + ' ' + data?.surname}
                  </span>
                );
              }
            })}
            {teamMember && teamMember?.length > 1 && (
              <span className="more-members">
                {' '}
                {`+${teamMember?.length - 1}`}
              </span>
            )}
          </div>
        </section>
      </section>
    </div>
  );
};
