import { Breadcrumb, Modal } from 'antd';
import React, { useEffect } from 'react';
import notificationThrower from '../../helpers/notificationThrower';
import { TeamMemberData } from '../../interfaces/TeamMember';
import {
  useCreateMemberMutation,
  useLazyGetSingleMemberQuery,
  useUpdateMemberMutation,
} from '../../redux/slices/teamMember/teamMemberApi';
import { teamMemberFormFields } from '../FormFields/TeamMemberFormFields';
import FormRender from '../FormRender';

interface TeamMemberModalProps {
  openMember: number | boolean | null;
  setOpenMember: React.Dispatch<React.SetStateAction<number | boolean | null>>;
}
export const TeamMemberModal: React.FC<TeamMemberModalProps> = ({
  openMember,
  setOpenMember,
}) => {
  const creatingNew = typeof openMember === 'boolean';
  const [getMember, { data }] = useLazyGetSingleMemberQuery();
  const [creatMember, { isLoading: createLoading }] = useCreateMemberMutation();
  const [updateMember, { isLoading: updateLoading }] =
    useUpdateMemberMutation();

  useEffect(() => {
    if (openMember && !creatingNew) {
      getMember(openMember, true)
        .unwrap()
        .catch(() => {
          notificationThrower({
            type: 'error',
            title: 'Failed To Get Member Data',
          });
        });
    }
  }, [openMember]);

  const handleSubmit = (formData: TeamMemberData) => {
    if (creatingNew) {
      creatMember(formData)
        .unwrap()
        .then(() => {
          notificationThrower({
            type: 'success',
            title: 'Member Created Successfully',
          });
          setOpenMember(null);
        })
        .catch(() => {
          notificationThrower({
            type: 'error',
            title: 'Failed To Create Member',
          });
        });
    } else {
      data &&
        updateMember({ id: data?.id, data: formData })
          .unwrap()
          .then(() => {
            notificationThrower({
              type: 'success',
              title: 'Member Updated Successfully',
            });
            setOpenMember(null);
          })
          .catch(() => {
            notificationThrower({
              type: 'error',
              title: 'Failed To Update Member',
            });
          });
    }
  };

  return (
    <Modal
      title={
        <Breadcrumb>
          <Breadcrumb.Item>Team Members</Breadcrumb.Item>
          <Breadcrumb.Item>{creatingNew ? 'Create' : 'Edit'}</Breadcrumb.Item>
        </Breadcrumb>
      }
      centered
      open={openMember !== null}
      footer={null}
      onCancel={() => {
        setOpenMember(null);
      }}
      className={'team-member-modal'}
    >
      <FormRender
        name={'team-member-form'}
        onFinish={handleSubmit}
        formFields={teamMemberFormFields}
        loading={createLoading || updateLoading}
        submitButton={creatingNew ? 'Create' : 'Save'}
        className={'team-member-form-render'}
        onCancel={() => {
          setOpenMember(null);
        }}
        initialValues={
          data && [
            {
              name: 'name',
              value: data?.name,
            },
            {
              name: 'surname',
              value: data?.surname,
            },
            {
              name: 'description',
              value: data?.description,
            },
          ]
        }
      />
    </Modal>
  );
};
