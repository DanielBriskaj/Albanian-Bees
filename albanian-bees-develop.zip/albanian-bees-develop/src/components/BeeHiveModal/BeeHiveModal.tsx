import { Breadcrumb, Form, Modal } from 'antd';
import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import notificationThrower from '../../helpers/notificationThrower';
import { BeeHiveData } from '../../interfaces/BeeHive';
import {
  beeHiveApi,
  useCreateHiveMutation,
  useLazyGetSingleHiveQuery,
  useUpdateHiveMutation,
} from '../../redux/slices/beeHive/beeHiveApi';
import { useGetAllParksQuery } from '../../redux/slices/park/parkApi';
import {
  useCreateSessionHiveDataMutation,
  useLazyGetSingleSessionHiveDataQuery,
  useUpdateSessionHiveDataMutation,
} from '../../redux/slices/sessions/beeHiveDataApi';
import { sessionsApi } from '../../redux/slices/sessions/sessionsApi';
import { beeHivesFormFields } from '../FormFields/BeeHiveFormFields';
import FormRender from '../FormRender';

interface BeeHiveModalProps {
  openHive: number | boolean | null;
  setOpenHive: React.Dispatch<React.SetStateAction<number | boolean | null>>;
  hivesArray: BeeHiveData[];
  setHivesArray: React.Dispatch<React.SetStateAction<BeeHiveData[]>>;
  session?: { id: number; updating: boolean };
}
export const BeeHivesModal: React.FC<BeeHiveModalProps> = ({
  openHive,
  setOpenHive,
  hivesArray,
  setHivesArray,
  session,
}) => {
  const dispatch = useDispatch();
  const [form] = Form.useForm();
  const creatingNew = typeof openHive === 'boolean';
  const foodSyrup = Form.useWatch('foodSyrup', form);
  const foodBread = Form.useWatch('foodBread', form);
  const [parkOptions, setParkOptions] = useState<
    Array<{ value: number; label: string }>
  >([]);
  const [data, setData] = useState<BeeHiveData>();
  const [getHive] = useLazyGetSingleHiveQuery();
  const [getSessionHiveData] = useLazyGetSingleSessionHiveDataQuery();
  const [createHive, { isLoading: createLoading }] = useCreateHiveMutation();
  const [updateHive, { isLoading: updateLoading }] = useUpdateHiveMutation();
  const [createSessionHive, { isLoading: sessionHiveLoading }] =
    useCreateSessionHiveDataMutation();
  const [updateSessionHive, { isLoading: sessionHiveUpdateLoading }] =
    useUpdateSessionHiveDataMutation();
  const { data: parkData = [] } = useGetAllParksQuery();

  useEffect(() => {
    if (openHive && !creatingNew && !session?.updating) {
      getHive(openHive, true)
        .unwrap()
        .then(payload => {
          setData(payload);
          form.setFieldsValue({
            ...payload,
            park: payload?.park?.id,
          });
        })
        .catch(() => {
          notificationThrower({
            type: 'error',
            title: 'Failed To Get Hive Data',
          });
        });
    } else if (openHive && session?.updating) {
      getSessionHiveData(
        {
          beeHiveId: Number(openHive),
          sessionId: session?.id,
        },
        true,
      )
        .unwrap()
        .then(payload => {
          setData(payload);
          form.setFieldsValue({
            ...payload,
            park: payload?.park
              ? payload?.park?.id
              : payload?.session?.park?.id,
          });
        })
        .catch(() => {
          notificationThrower({
            type: 'error',
            title: 'Failed To Get Hive Data',
          });
        });
    }
  }, [openHive]);

  useEffect(() => {
    setParkOptions(
      parkData?.map(park => {
        return {
          value: park?.id,
          label: park?.name,
        };
      }),
    );
  }, [parkData]);

  const handleSubmit = (formData: any) => {
    const transformedData = {
      ...data,
      ...formData,
      park: {
        id: formData?.park,
      },
    };
    if (session) {
      if (!session?.updating) {
        createSessionHive({
          data: { ...transformedData },
          isSession: true,
          processId: session?.id,
        })
          .unwrap()
          .then(() => {
            dispatch(beeHiveApi.util.invalidateTags(['SessionHives']));
            dispatch(sessionsApi.util?.invalidateTags(['Session']));
            setOpenHive(null);
            notificationThrower({
              type: 'success',
              title: 'Hive Data Added Successfully',
            });
          })
          .catch(() => {
            notificationThrower({
              type: 'error',
              title: 'Failed To Add Hive Data',
            });
          });
      } else {
        updateSessionHive({
          data: { ...transformedData },
          beeHiveDataId: Number(data?.id),
        })
          .unwrap()
          .then(() => {
            notificationThrower({
              type: 'success',
              title: 'Hive Data Updated Successfully',
            });
            setOpenHive(null);
          })
          .catch(() => {
            notificationThrower({
              type: 'error',
              title: 'Failed To Update Hive Data',
            });
          });
      }
    } else {
      if (creatingNew) {
        createHive(transformedData)
          .unwrap()
          .then(payload => {
            notificationThrower({
              type: 'success',
              title: 'Hive Created Successfully',
            });
            setOpenHive(null);
            setHivesArray([{ ...payload }, ...hivesArray]);
          })
          .catch(() => {
            notificationThrower({
              type: 'error',
              title: 'Failed To Create Hive',
            });
          });
      } else {
        data &&
          updateHive({ id: data?.id, data: transformedData })
            .unwrap()
            .then(() => {
              notificationThrower({
                type: 'success',
                title: 'Hive Updated Successfully',
              });
              setOpenHive(null);
              const newState = hivesArray?.map(hive => {
                if (hive?.id === data?.id) {
                  return { id: data?.id, ...transformedData };
                }
                return hive;
              });
              setHivesArray(newState);
            })
            .catch(() => {
              notificationThrower({
                type: 'error',
                title: 'Failed To Update Hive',
              });
            });
      }
    }
  };

  const handleValuesChange = (_: any, values: BeeHiveData) => {
    const honey = values?.honey ? values?.honey : 0;
    const oldBrood = values?.olderBroot ? values?.olderBroot : 0;
    const newBrood = values?.newBroot ? values?.newBroot : 0;
    const empty = values?.empty ? values?.empty : 0;

    const total = honey + oldBrood + newBrood + empty;

    form.setFieldValue('frames', total);
  };

  return (
    <Modal
      title={
        <Breadcrumb>
          <Breadcrumb.Item>Bee Hives</Breadcrumb.Item>
          <Breadcrumb.Item>{creatingNew ? 'Create' : 'Edit'}</Breadcrumb.Item>
        </Breadcrumb>
      }
      width={800}
      centered
      open={openHive !== null}
      footer={null}
      onCancel={() => {
        setOpenHive(null);
      }}
      className={'bee-hive-modal'}
    >
      <FormRender
        name={'bee-hive-form'}
        onFinish={handleSubmit}
        formFields={beeHivesFormFields(
          parkOptions,
          form,
          foodBread,
          foodSyrup,
          session,
        )}
        loading={
          createLoading ||
          updateLoading ||
          sessionHiveLoading ||
          sessionHiveUpdateLoading
        }
        submitButton={creatingNew ? 'Create' : 'Save'}
        className={'bee-hive-form-render'}
        onCancel={() => {
          setOpenHive(null);
        }}
        form={form}
        onValuesChange={handleValuesChange}
      />
    </Modal>
  );
};
