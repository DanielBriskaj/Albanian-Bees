export { BeeHivesModal as default } from './BeeHiveModal';
