import { Breadcrumb, Modal } from 'antd';
import React, { useEffect, useState } from 'react';
import { CirclePicker } from 'react-color';
import {
  MapContainer,
  Marker,
  TileLayer,
  useMap,
  useMapEvents,
} from 'react-leaflet';
import { MapSearch } from '../../helpers/mapSearch';
import notificationThrower from '../../helpers/notificationThrower';
import { ParkData } from '../../interfaces/Park';
import {
  useCreateParkMutation,
  useLazyGetSingleParkQuery,
  useUpdateParkMutation,
} from '../../redux/slices/park/parkApi';
import { parkFormFields } from '../FormFields/ParkFormFields';
import FormRender from '../FormRender';

interface ParkModalProps {
  openPark: number | boolean | null;
  setOpenPark: React.Dispatch<React.SetStateAction<number | boolean | null>>;
}
export const ParkModal: React.FC<ParkModalProps> = ({
  openPark,
  setOpenPark,
}) => {
  const [selectedColor, setSelectedColor] = useState<string>('#db7c00');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [marker, setMarker] = useState<{ lat: number; lng: number }>({
    lat: 41.3275,
    lng: 19.8187,
  });
  const creatingNew = typeof openPark === 'boolean';
  const [getPark, { data }] = useLazyGetSingleParkQuery();
  const [createPark, { isLoading: createLoading }] = useCreateParkMutation();
  const [updatePark, { isLoading: updateLoading }] = useUpdateParkMutation();

  useEffect(() => {
    if (openPark && !creatingNew) {
      getPark(openPark, true)
        .unwrap()
        .then(payload => {
          setMarker({ lat: payload?.latitude, lng: payload?.longitude });
          setSelectedColor(payload?.colorCode);
        })
        .catch(() => {
          notificationThrower({
            type: 'error',
            title: 'Failed To Get Park Data',
          });
        });
    }
  }, [openPark]);

  const handleSubmit = (formData: ParkData) => {
    const transformerData = {
      ...formData,
      colorCode: selectedColor,
      latitude: marker?.lat,
      longitude: marker?.lng,
    };

    if (creatingNew) {
      createPark(transformerData)
        .unwrap()
        .then(() => {
          notificationThrower({
            type: 'success',
            title: 'Park Created Successfully',
          });
          setOpenPark(null);
        })
        .catch(error => {
          error?.originalStatus === 400
            ? setErrorMessage('This color is already used on a different park')
            : notificationThrower({
                type: 'error',
                title: 'Failed To Create Park',
              });
        });
    } else {
      data &&
        updatePark({ id: data?.id, data: transformerData })
          .unwrap()
          .then(() => {
            notificationThrower({
              type: 'success',
              title: 'Park Updated Successfully',
            });
            setOpenPark(null);
          })
          .catch(error => {
            error?.originalStatus === 400
              ? setErrorMessage(
                  'This color is already used on a different park',
                )
              : notificationThrower({
                  type: 'error',
                  title: 'Failed To Update Park',
                });
          });
    }
  };

  function AddMarkerToClick() {
    const map = useMapEvents({
      click(e: any) {
        const newMarker = e.latlng;
        setMarker(newMarker);
      },
    });

    return <>{marker && <Marker position={marker}></Marker>}</>;
  }

  function ChangeView({ center, zoom }: any) {
    const map = useMap();
    map.setView(center, zoom);
    return null;
  }

  return (
    <Modal
      title={
        <Breadcrumb>
          <Breadcrumb.Item>Parks</Breadcrumb.Item>
          <Breadcrumb.Item>
            {creatingNew ? 'Create Park' : 'Edit Park'}
          </Breadcrumb.Item>
        </Breadcrumb>
      }
      centered
      open={openPark !== null}
      footer={null}
      onCancel={() => {
        setOpenPark(null);
      }}
      className={'park-modal'}
    >
      <FormRender
        name={'park-form'}
        onFinish={handleSubmit}
        formFields={parkFormFields}
        loading={createLoading || updateLoading}
        submitButton={creatingNew ? 'Create' : 'Save'}
        onCancel={() => {
          setOpenPark(null);
        }}
        className={'park-form-render'}
        formEnd={
          <div className="form-footer">
            <div className="color-container">
              <section>
                <div>
                  <span>Select Park Color</span>

                  <CirclePicker
                    className="color-picker"
                    circleSize={20}
                    circleSpacing={8}
                    colors={[
                      '#db7c00',
                      '#9c27b0',
                      '#3f51b5',
                      '#03a9f4',
                      '#4caf50',
                      '#607d8b',
                      '#db3e00',
                    ]}
                    onChange={(e: { hex: string }) => setSelectedColor(e?.hex)}
                  />
                </div>
                <div
                  className="show-selected"
                  style={{ background: selectedColor }}
                ></div>
              </section>
              {errorMessage && <div className="error">{errorMessage}</div>}
            </div>
            <div className="modal-map">
              <MapContainer center={[marker?.lat, marker?.lng]} zoom={12}>
                <MapSearch />
                <ChangeView center={[marker?.lat, marker?.lng]} zoom={12} />
                <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                <AddMarkerToClick />
              </MapContainer>
            </div>
          </div>
        }
        initialValues={
          data && [
            {
              name: 'name',
              value: data?.name,
            },
            {
              name: 'description',
              value: data?.description,
            },
          ]
        }
      />
    </Modal>
  );
};
