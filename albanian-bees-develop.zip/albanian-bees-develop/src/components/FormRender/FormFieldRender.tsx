import React from 'react';
import { FormField } from '../../interfaces/FormInterfaces';
import InputField from './FormFields/Input';
import InputPassword from './FormFields/InputPassword';
import AntdSelect from './FormFields/AntdSelect';
import { FORM_FIELD } from '../../constants/enums/formEnums';
import NumberInput from './FormFields/InputNumber';
import AntdCheckbox from './FormFields/AntdCheckbox';
import AntdSwitch from './FormFields/AntdSwitch';
import TextAreaField from './FormFields/TextArea';
import FormSection from './FormFields/FormSection';
import DatePickerField from './FormFields/DatePicker';

const FormFieldRender: any = ({ data }: { data: FormField }) => {
  switch (data?.type) {
    case FORM_FIELD.INPUT:
      return <InputField {...data} />;
    case FORM_FIELD.PASSWORD:
      return <InputPassword {...data} />;
    case FORM_FIELD.NUMBER:
      return <NumberInput {...data} />;
    case FORM_FIELD.CHECKBOX:
      return <AntdCheckbox {...data} />;
    case FORM_FIELD.ANTD_SELECT:
      return <AntdSelect {...data} />;
    case FORM_FIELD.SWITCH:
      return <AntdSwitch {...data} />;
    case FORM_FIELD.TEXT_AREA:
      return <TextAreaField {...data} />;
    case FORM_FIELD.SECTION:
      return <FormSection {...data} />;
    case FORM_FIELD.DATE:
      return <DatePickerField {...data} />;
    default:
      return <span></span>;
  }
};

export default FormFieldRender;
