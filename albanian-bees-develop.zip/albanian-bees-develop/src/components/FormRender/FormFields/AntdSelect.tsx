import { Form, Select } from 'antd';
import React from 'react';
import { FormField } from '../../../interfaces/FormInterfaces';

const { Option } = Select;
const AntdSelect = (props: FormField) => {
  return (
    <Form.Item
      name={props?.name}
      dependencies={props?.dependencies}
      rules={props?.rules}
    >
      <Select {...props} placeholder={''} {...props?.otherprops}>
        {props?.options.map((data: any, i: number) => {
          return (
            <Option key={i} value={data?.value} disabled={data?.disabled}>
              {data?.label}
            </Option>
          );
        })}
      </Select>
    </Form.Item>
  );
};

export default AntdSelect;
