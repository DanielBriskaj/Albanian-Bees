import React from 'react';
import { Form, Input } from 'antd';
import { FormField } from '../../../interfaces/FormInterfaces';

const TextAreaField = (props: FormField) => {
  const { TextArea } = Input;
  return (
    <Form.Item
      name={props?.name}
      dependencies={props?.dependencies}
      rules={props?.rules}
    >
      <TextArea
        className={`text-area-field ${props?.className}`}
        rows={props?.rows}
        placeholder={''}
        {...props?.otherprops}
      />
    </Form.Item>
  );
};

export default TextAreaField;
