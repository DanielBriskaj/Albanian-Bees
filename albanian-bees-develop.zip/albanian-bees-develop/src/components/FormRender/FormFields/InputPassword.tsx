import React from 'react';
import { Form, Input } from 'antd';
import { FormField } from '../../../interfaces/FormInterfaces';

const InputPassword = (props: FormField) => {
  return (
    <Form.Item
      name={props?.name}
      dependencies={props?.dependencies}
      rules={props?.rules}
    >
      <Input.Password
        className={`password-field ${props?.className}`}
        placeholder={''}
        {...props?.otherprops}
      />
    </Form.Item>
  );
};

export default InputPassword;
