import React from 'react';
import { Form, Input } from 'antd';
import { FormField } from '../../../interfaces/FormInterfaces';

const InputField = (props: FormField) => {
  return (
    <Form.Item
      name={props?.name}
      dependencies={props?.dependencies}
      rules={props?.rules}
    >
      <Input
        className={`input-field ${props?.className}`}
        placeholder={''}
        {...props?.otherprops}
      />
    </Form.Item>
  );
};

export default InputField;
