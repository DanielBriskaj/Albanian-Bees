import React from 'react';
import { FormField } from '../../../interfaces/FormInterfaces';

const FormSection = (props: FormField) => {
  return <div className="form-section-label">{props?.name}</div>;
};

export default FormSection;
