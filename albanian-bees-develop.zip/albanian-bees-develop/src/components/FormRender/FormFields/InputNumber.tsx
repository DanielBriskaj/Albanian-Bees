import React from 'react';
import { Form, InputNumber } from 'antd';
import { FormField } from '../../../interfaces/FormInterfaces';

const NumberInput = (props: FormField) => {
  return (
    <Form.Item
      name={props?.name}
      dependencies={props?.dependencies}
      rules={props?.rules}
    >
      <InputNumber
        className={`input-field ${props?.className}`}
        placeholder={''}
        {...props?.otherprops}
      />
    </Form.Item>
  );
};

export default NumberInput;
