import React from 'react';
import { DatePicker, Form } from 'antd';
import { FormField } from '../../../interfaces/FormInterfaces';

const DatePickerField = (props: FormField) => {
  return (
    <Form.Item
      name={props?.name}
      dependencies={props?.dependencies}
      rules={props?.rules}
    >
      <DatePicker
        className={`input-field ${props?.className}`}
        placeholder={''}
        {...props?.otherprops}
      />
    </Form.Item>
  );
};

export default DatePickerField;
