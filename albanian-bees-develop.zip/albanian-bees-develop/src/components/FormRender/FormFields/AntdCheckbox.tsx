import React from 'react';
import { Checkbox, Form } from 'antd';
import { FormField } from '../../../interfaces/FormInterfaces';

const AntdCheckbox = (props: FormField) => {
  return (
    <Form.Item
      name={props?.name}
      dependencies={props?.dependencies}
      rules={props?.rules}
      valuePropName="checked"
    >
      <Checkbox
        className={`checkbox-field ${props?.className}`}
        placeholder={props?.placeholder}
        {...props?.otherprops}
      />
    </Form.Item>
  );
};

export default AntdCheckbox;
