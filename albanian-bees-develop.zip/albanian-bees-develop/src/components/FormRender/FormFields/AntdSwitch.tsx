import React from 'react';
import { Switch, Form } from 'antd';
import { FormField } from '../../../interfaces/FormInterfaces';

const AntdSwitch = (props: FormField) => {
  return (
    <Form.Item
      name={props?.name}
      dependencies={props?.dependencies}
      rules={props?.rules}
      valuePropName="checked"
    >
      <Switch
        className={`switch-field ${props?.className}`}
        placeholder={props?.placeholder}
        {...props?.otherprops}
      />
    </Form.Item>
  );
};

export default AntdSwitch;
