import { Form } from 'antd';
import React from 'react';
import { formItemWidth } from '../../helpers/formItemsWidth';
import { FormField, FormRenderProps } from '../../interfaces/FormInterfaces';
import FormFieldRender from './FormFieldRender';

export const FormRender: React.FC<FormRenderProps> = ({
  name,
  onFinish,
  formFields,
  formEnd,
  loading,
  submitButton,
  errorMessage,
  customEndButtons,
  className,
  style,
  initialValues,
  onCancel,
  form,
  onValuesChange,
}) => {
  return (
    <Form
      name={name}
      onFinish={onFinish}
      className={`from-render ${className}`}
      style={style}
      fields={initialValues}
      form={form}
      onValuesChange={onValuesChange}
    >
      {errorMessage && <div className="form-error">{errorMessage}</div>}
      {formFields.map((data: FormField, i: number) => {
        const width = data?.width && formItemWidth(data?.width);

        return (
          <React.Fragment key={i}>
            {data?.label ? (
              <div
                style={{
                  flexBasis: `${width}%`,
                  flexGrow: 0,
                  maxWidth: `${width}%`,
                  padding: `${width ? '0 10px' : 0}`,
                }}
                className="input-with-label"
              >
                <span className="form-item-label">{data?.label}</span>
                <FormFieldRender data={data} />
              </div>
            ) : (
              <div
                style={{
                  flexBasis: `${width}%`,
                  flexGrow: 0,
                  maxWidth: `${width}%`,
                  padding: `${width ? '0 10px' : 0}`,
                }}
                className="input-with-placeholder"
              >
                <span
                  style={{ left: `${width ? '20px' : '10px'}` }}
                  className="form-item-placeholder"
                >
                  {data?.placeholder}
                </span>
                <FormFieldRender data={data} />
              </div>
            )}
          </React.Fragment>
        );
      })}
      {formEnd}

      {submitButton && (
        <div className="form-submit">
          {onCancel && (
            <button className="btn-cancel" type="button" onClick={onCancel}>
              Cancel
            </button>
          )}
          <Form.Item>
            <button className="btn-primary" type="submit" disabled={loading}>
              {submitButton}
            </button>
          </Form.Item>
        </div>
      )}
      {customEndButtons && <Form.Item>{customEndButtons}</Form.Item>}
    </Form>
  );
};
