import React from 'react';
import notificationThrower from '../../helpers/notificationThrower';
import { ParkData } from '../../interfaces/Park';
import { ReactComponent as Edit } from '../../assets/svgIcons/pencil-fill.svg';
import { ReactComponent as Delete } from '../../assets/svgIcons/trash-fill.svg';
import { ReactComponent as Location } from '../../assets/svgIcons/geo-alt-fill.svg';
import { useDeleteParkMutation } from '../../redux/slices/park/parkApi';
import { Modal } from 'antd';

interface ParkCardProps extends ParkData {
  setOpenPark: React.Dispatch<React.SetStateAction<number | boolean | null>>;
}

export const ParkCard: React.FC<ParkCardProps> = ({
  id,
  name,
  description,
  colorCode,
  setOpenPark,
}) => {
  const { confirm } = Modal;
  const [deletePark] = useDeleteParkMutation();

  const handleOpenForm = () => {
    setOpenPark(id);
  };

  const showConfirm = () => {
    confirm({
      title: `Are you sure you want to delete ${name}?`,
      centered: true,
      maskClosable: true,
      onOk() {
        handleDeletePark();
      },
      okText: 'Yes',
      cancelText: 'No',
    });
  };

  const handleDeletePark = () => {
    deletePark(id)
      .unwrap()
      .then(() => {
        notificationThrower({
          type: 'success',
          title: `Park Deleted Successfully`,
        });
      })
      .catch(() => {
        notificationThrower({
          type: 'error',
          title: `Failed To Delete Park`,
        });
      });
  };

  return (
    <div
      className="park-card-container"
      style={{
        border: `1px solid ${colorCode}`,
        boxShadow: `0px 3px 5px ${colorCode}69`,
      }}
    >
      <section className="icon">
        <Location className="svg" />
      </section>
      <section className="data">
        <section className="top-section">
          <div className="name">{name}</div>
          <div className="icons">
            <Edit className="svg" onClick={handleOpenForm} />
            <Delete className="svg" onClick={showConfirm} />
          </div>
        </section>
        <div className="description">{description}</div>
      </section>
    </div>
  );
};
