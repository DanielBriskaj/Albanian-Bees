export { TeamMemberCard as default } from './TeamMemberCard';
