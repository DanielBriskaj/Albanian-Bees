import React from 'react';
import { TeamMemberData } from '../../interfaces/TeamMember';
import { ReactComponent as Edit } from '../../assets/svgIcons/pencil-fill.svg';
import { ReactComponent as Delete } from '../../assets/svgIcons/trash-fill.svg';
import { ReactComponent as Team } from '../../assets/svgIcons/businessman-team.svg';
import { Modal } from 'antd';
import { useDeleteMemberMutation } from '../../redux/slices/teamMember/teamMemberApi';
import notificationThrower from '../../helpers/notificationThrower';

interface TeamMemberCardProps extends TeamMemberData {
  setOpenMember: React.Dispatch<React.SetStateAction<number | boolean | null>>;
}

export const TeamMemberCard: React.FC<TeamMemberCardProps> = ({
  name,
  surname,
  description,
  id,
  setOpenMember,
}) => {
  const { confirm } = Modal;
  const [deleteMember] = useDeleteMemberMutation();

  const handleOpenForm = () => {
    setOpenMember(id);
  };

  const showConfirm = () => {
    confirm({
      title: `Are you sure you want to delete ${name + ' ' + surname}?`,
      centered: true,
      maskClosable: true,
      onOk() {
        handleDeleteMember();
      },
      okText: 'Yes',
      cancelText: 'No',
    });
  };

  const handleDeleteMember = () => {
    deleteMember(id)
      .unwrap()
      .then(() => {
        notificationThrower({
          type: 'success',
          title: `Member Deleted Successfully`,
        });
      })
      .catch(() => {
        notificationThrower({
          type: 'error',
          title: `Failed To Delete Member`,
        });
      });
  };

  return (
    <div className="team-member-card-container">
      <section className="icon">
        <Team className="svg" />
      </section>
      <section className="data">
        <section className="top-section">
          <div className="name">{name + ' ' + surname}</div>
          <div className="icons">
            <Edit className="svg" onClick={handleOpenForm} />
            <Delete className="svg" onClick={showConfirm} />
          </div>
        </section>
        <div className="description">{description}</div>
      </section>
    </div>
  );
};
