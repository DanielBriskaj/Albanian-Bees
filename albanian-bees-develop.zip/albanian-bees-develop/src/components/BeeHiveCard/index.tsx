export { BeeHiveCard as default } from './BeeHiveCard';
