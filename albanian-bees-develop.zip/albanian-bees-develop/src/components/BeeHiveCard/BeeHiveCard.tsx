import React from 'react';
import { ReactComponent as Edit } from '../../assets/svgIcons/pencil-fill.svg';
import { ReactComponent as Delete } from '../../assets/svgIcons/trash-fill.svg';
import { ReactComponent as Bee } from '../../assets/svgIcons/bee.svg';
import { ReactComponent as Medication } from '../../assets/svgIcons/medicine.svg';

import { Modal } from 'antd';
import notificationThrower from '../../helpers/notificationThrower';
import { BeeHiveData } from '../../interfaces/BeeHive';
import { useDeleteHiveMutation } from '../../redux/slices/beeHive/beeHiveApi';

interface BeeHiveCardProps extends BeeHiveData {
  setOpenHive: React.Dispatch<React.SetStateAction<number | boolean | null>>;
  hivesArray: BeeHiveData[];
  setHivesArray: React.Dispatch<React.SetStateAction<BeeHiveData[]>>;
}

export const BeeHiveCard: React.FC<BeeHiveCardProps> = ({
  id,
  setOpenHive,
  queenValue,
  medicationValue,
  park,
  frames,
  hiveIdentifierValue,
  rating,
  hivesArray,
  setHivesArray,
}) => {
  const { confirm } = Modal;
  const [deleteHive] = useDeleteHiveMutation();

  const handleOpenForm = () => {
    setOpenHive(id);
  };

  const showConfirm = () => {
    confirm({
      title: `Are you sure you want to delete ${hiveIdentifierValue}?`,
      centered: true,
      maskClosable: true,
      onOk() {
        handleDeleteHive();
      },
      okText: 'Yes',
      cancelText: 'No',
    });
  };

  const handleDeleteHive = () => {
    deleteHive(id)
      .unwrap()
      .then(() => {
        const newState = hivesArray.filter(hive => hive?.id !== id);
        setHivesArray(newState);

        notificationThrower({
          type: 'success',
          title: `Hive Deleted Successfully`,
        });
      })
      .catch(() => {
        notificationThrower({
          type: 'error',
          title: `Failed To Delete Hive`,
        });
      });
  };

  const returnQueenLabel = () => {
    switch (queenValue) {
      case 'NEW':
        return 'New';
      case 'OLDER_THAN_2_YEARS':
        return '2+ Years';
      case 'NO_QUEEN':
        return 'Missing';
      default:
        break;
    }
  };

  const returnMedicationLabel = () => {
    switch (medicationValue) {
      case 'NOZEMA':
        return 'Nozema';
      case 'NO_MEDICATION':
        return 'No Meds';
      case 'OTHERS':
        return 'Others';
      case 'VAROA':
        return 'Varoa';
      default:
        break;
    }
  };
  const returnRatingLabel = () => {
    switch (rating) {
      case 'EXCELLENT':
        return 'Excellent';
      case 'GOOD':
        return 'Good';
      case 'NEUTRAL':
        return 'Neutral';
      case 'NOT_GOOD':
        return 'Not Good';
      case 'BAD':
        return 'Bad';
      default:
        break;
    }
  };

  return (
    <div className="bee-hive-card-container">
      <section className="data">
        <section className="top-section">
          <div className="name">
            <div
              className="park-color"
              style={{
                background: park?.colorCode ? park?.colorCode : '#db7c00',
              }}
            ></div>
            <span>
              {hiveIdentifierValue} {`- ${returnRatingLabel()}`}
            </span>
          </div>
          <div className="icons">
            <Edit className="svg" onClick={handleOpenForm} />
            <Delete className="svg" onClick={showConfirm} />
          </div>
        </section>

        <section className="bottom-section">
          <div className="first-part">
            <div className="queen">
              <Bee className="bee-svg" />
              {returnQueenLabel()}
            </div>
            <div className="medication">
              <Medication className="med-svg" />
              {returnMedicationLabel()}
            </div>
          </div>
          <div className="frames">
            <span>{frames} </span> Frames
          </div>
        </section>
      </section>
    </div>
  );
};
