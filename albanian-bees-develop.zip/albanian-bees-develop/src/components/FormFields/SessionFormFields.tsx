import { FORM_FIELD } from '../../constants/enums/formEnums';
import { SMOKER } from '../../constants/enums/smoker';
import { FormField, NumberOptionsProps } from '../../interfaces/FormInterfaces';

export const SmokerOptions = [
  { value: SMOKER.CARDBOX, label: 'Cardbox' },
  { value: SMOKER.WOOD, label: 'Wood' },
];

export const sessionFormFields = (
  parkOptions: NumberOptionsProps[],
  memberOptions: NumberOptionsProps[],
) => {
  const fields: FormField[] = [
    {
      name: 'name',
      type: FORM_FIELD.INPUT,
      rules: [
        {
          required: true,
          message: 'Field Is Required',
        },
        { max: 50, message: 'Maximum 50 characters' },
      ],
      placeholder: 'Session Name',
    },
    {
      name: 'park',
      type: FORM_FIELD.ANTD_SELECT,
      rules: [
        {
          required: true,
          message: 'Field Is Required',
        },
      ],
      placeholder: 'Park',
      options: parkOptions,
    },
    {
      name: 'smoker',
      type: FORM_FIELD.ANTD_SELECT,
      rules: [
        {
          required: true,
          message: 'Field Is Required',
        },
      ],
      placeholder: 'Smoker',
      options: SmokerOptions,
    },

    {
      name: 'teamMember',
      type: FORM_FIELD.ANTD_SELECT,
      rules: [
        {
          required: true,
          message: 'Field Is Required',
        },
      ],
      placeholder: 'Team Members',
      options: memberOptions,
      otherprops: {
        mode: 'multiple',
        allowClear: true,
        showArrow: true,
      },
    },
  ];

  return fields;
};
