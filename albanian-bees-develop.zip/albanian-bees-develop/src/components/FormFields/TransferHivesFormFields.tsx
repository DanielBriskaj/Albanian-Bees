import { FORM_FIELD } from '../../constants/enums/formEnums';
import { FormField } from '../../interfaces/FormInterfaces';

export const transferHivesFormFields = (
  parkOptions: Array<{ value: number; label: string }>,
  hiveOptions: Array<{ value: number; label: string }>,
) => {
  const fields: FormField[] = [
    {
      name: 'fromParkId',
      type: FORM_FIELD.ANTD_SELECT,
      rules: [
        {
          required: true,
          message: 'Select Source Park',
        },
      ],
      placeholder: 'From Park',
      options: parkOptions,
    },
    {
      name: 'toParkId',
      type: FORM_FIELD.ANTD_SELECT,
      rules: [
        {
          required: true,
          message: 'Select Destination Park',
        },
      ],
      placeholder: 'To Park',
      options: parkOptions,
    },
    {
      name: 'beeHiveToTransferId',
      type: FORM_FIELD.ANTD_SELECT,
      rules: [
        {
          required: true,
          message: 'Select Hive To Transfer',
        },
      ],
      placeholder: 'Hive',
      options: hiveOptions,
    },
    {
      name: 'description',
      type: FORM_FIELD.TEXT_AREA,
      rules: [
        {
          required: true,
          message: 'Please add transfer description',
        },
        {
          max: 250,
          message: 'Maximum 250 Characters',
        },
      ],
      placeholder: 'Description',
    },
  ];
  return fields;
};
