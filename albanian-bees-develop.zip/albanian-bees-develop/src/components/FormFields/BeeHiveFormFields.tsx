import { FormInstance } from 'antd/lib/form';
import { BREEDS } from '../../constants/enums/breeds';
import { FORM_FIELD } from '../../constants/enums/formEnums';
import { MEDICATIONS } from '../../constants/enums/medications';
import { QUEEN } from '../../constants/enums/queenValues';
import { RATING } from '../../constants/enums/rating';
import { FormField } from '../../interfaces/FormInterfaces';

export const BreedOptions = [
  { value: BREEDS?.AFRICAN, label: 'African' },
  { value: BREEDS?.BUCKFAST, label: 'Buckfast' },
  { value: BREEDS?.CARNIOLAN, label: 'Carniolan' },
  { value: BREEDS?.CAUCASIAN, label: 'Caucasian' },
  { value: BREEDS?.CORDOVAN, label: 'Cordovan' },
  { value: BREEDS?.ITALIAN, label: 'Italian' },
  { value: BREEDS?.RUSSIAN, label: 'Russian' },
];

export const QueenOptions = [
  { value: '', label: 'All' },
  { value: QUEEN?.NO_QUEEN, label: 'No Queen' },
  { value: QUEEN?.NEW, label: 'New' },
  { value: QUEEN?.OLDER_THAN_2_YEARS, label: 'Older than 2 years' },
];
export const MedicationOptions = [
  { value: '', label: 'All' },
  { value: MEDICATIONS?.NO_MEDICATION, label: 'No Medication' },
  { value: MEDICATIONS?.NOZEMA, label: 'Nozema' },
  { value: MEDICATIONS?.VAROA, label: 'Varoa' },
  { value: MEDICATIONS?.OTHERS, label: 'Others' },
];

export const RatingOptions = [
  { value: RATING.EXCELLENT, label: 'Excellent' },
  { value: RATING.GOOD, label: 'Good' },
  { value: RATING.NEUTRAL, label: 'Neutral' },
  { value: RATING.NOT_GOOD, label: 'Not Good' },
  { value: RATING.BAD, label: 'Bad' },
];
export const beeHivesFormFields = (
  parkOptions: Array<{ value: number; label: string }>,
  form: FormInstance<any>,
  foodBread: boolean,
  foodSyrup: boolean,
  session?: { id: number; updating: boolean },
) => {
  const { innerWidth: width } = window;

  const fields: FormField[] | any = [
    {
      name: 'hiveIdentifierValue',
      type: FORM_FIELD.INPUT,
      width: {
        lg: 66.66,
        md: 66.66,
        sm: 50,
        xs: 50,
      },
      rules: [
        {
          required: true,
          message: 'Field Is Required',
        },
        {
          max: 50,
          message: 'Maximum 50 Characters',
        },
      ],
      otherprops: {
        disabled: session,
      },
      placeholder: 'Hive SN',
    },
    {
      name: 'park',
      type: FORM_FIELD.ANTD_SELECT,
      width: {
        lg: 33.33,
        md: 33.33,
        sm: 50,
        xs: 50,
      },
      rules: [
        {
          required: true,
          message: 'Field Is Required',
        },
      ],
      otherprops: {
        disabled: session,
      },
      placeholder: 'Park',
      options: parkOptions,
    },
    {
      name: 'size',
      type: FORM_FIELD.NUMBER,
      width: {
        lg: 33.33,
        md: 33.33,
        sm: 50,
        xs: 50,
      },
      rules: [
        {
          required: true,
          message: 'Field Is Required',
        },
      ],
      placeholder: 'Size',
      otherprops: {
        min: 1,
        max: 5,
      },
    },
    {
      name: 'framesOfBees',
      type: FORM_FIELD.NUMBER,
      width: {
        lg: 33.33,
        md: 33.33,
        sm: 50,
        xs: 50,
      },
      rules: [
        {
          required: true,
          message: 'Field Is Required',
        },
      ],
      placeholder: 'Frames Of Bees',
      otherprops: {
        min: 1,
        max: 50,
      },
    },
    {
      name: 'breed',
      type: FORM_FIELD.ANTD_SELECT,
      width: {
        lg: 33.33,
        md: 33.33,
        sm: 50,
        xs: 50,
      },
      rules: [
        {
          required: true,
          message: 'Field Is Required',
        },
      ],
      placeholder: 'Breed',
      options: BreedOptions,
    },
    {
      name: 'honey',
      type: FORM_FIELD.NUMBER,
      width: {
        lg: 33.33,
        md: 33.33,
        sm: 50,
        xs: 50,
      },
      rules: [
        {
          required: true,
          message: 'Field Is Required',
        },
      ],
      placeholder: 'Honey Frames',
      otherprops: {
        min: 0,
        max: 50,
      },
    },
    {
      name: 'newBroot',
      type: FORM_FIELD.NUMBER,
      width: {
        lg: 33.33,
        md: 33.33,
        sm: 50,
        xs: 50,
      },
      rules: [
        {
          required: true,
          message: 'Field Is Required',
        },
      ],
      placeholder: 'New Brood Frames',
      otherprops: {
        min: 0,
        max: 50,
      },
    },
    {
      name: 'olderBroot',
      type: FORM_FIELD.NUMBER,
      width: {
        lg: 33.33,
        md: 33.33,
        sm: 50,
        xs: 50,
      },
      rules: [
        {
          required: true,
          message: 'Field Is Required',
        },
      ],
      placeholder: 'Old Brood Frames',
      otherprops: {
        min: 0,
        max: 50,
      },
    },
    {
      name: 'empty',
      type: FORM_FIELD.NUMBER,
      width: {
        lg: 33.33,
        md: 33.33,
        sm: 50,
        xs: 50,
      },
      rules: [
        {
          required: true,
          message: 'Field Is Required',
        },
      ],
      placeholder: 'Empty Frames',
      otherprops: {
        min: 0,
        max: 50,
      },
    },
    {
      name: 'frames',
      type: FORM_FIELD.NUMBER,
      width: {
        lg: 33.33,
        md: 33.33,
        sm: 50,
        xs: 50,
      },
      dependencies: ['honey', 'newBroot', 'olderBroot', 'empty', 'size'],
      rules: [
        {
          required: true,
          message: 'Field Is Required',
        },

        ({ getFieldValue }: any) => ({
          validator(_: any, value: number) {
            const size = getFieldValue('size');
            if (
              (size === 1 && value > 10) ||
              (size === 2 && value > 20) ||
              (size === 3 && value > 30) ||
              (size === 4 && value > 40) ||
              (size === 5 && value > 50)
            ) {
              return Promise.reject('Too Many Frames');
            }
            return Promise.resolve();
          },
        }),
      ],
      placeholder: 'Total Frames',
      otherprops: {
        min: 1,
        max: 50,
        disabled: true,
      },
    },
    {
      name: 'activeStatus',
      type: FORM_FIELD.ANTD_SELECT,
      width: {
        lg: 33.33,
        md: 33.33,
        sm: 50,
        xs: 50,
      },
      rules: [
        {
          required: true,
          message: 'Field Is Required',
        },
      ],
      placeholder: 'Status',
      options: [
        { value: true, label: 'Active' },
        { value: false, label: 'Inactive' },
      ],
    },
    {
      name: 'rating',
      type: FORM_FIELD.ANTD_SELECT,
      width: {
        lg: 33.33,
        md: 33.33,
        sm: 50,
        xs: 50,
      },
      rules: [
        {
          required: true,
          message: 'Field Is Required',
        },
      ],
      placeholder: 'Rating',
      options: RatingOptions,
    },

    {
      name: 'queenValue',
      type: FORM_FIELD.ANTD_SELECT,
      width: {
        lg: 33.33,
        md: 33.33,
        sm: 50,
        xs: 50,
      },
      rules: [
        {
          required: true,
          message: 'Field Is Required',
        },
      ],
      placeholder: 'Queen',
      options: QueenOptions.filter(option => option.label !== 'All'),
    },
    {
      name: 'medicationValue',
      type: FORM_FIELD.ANTD_SELECT,
      width: {
        lg: 33.33,
        md: 33.33,
        sm: 50,
        xs: 50,
      },
      rules: [
        {
          required: true,
          message: 'Field Is Required',
        },
      ],
      placeholder: 'Medication',
      options: MedicationOptions.filter(option => option.label !== 'All'),
    },
    width > 540 && {
      name: 'foodBread',
      type: FORM_FIELD.SWITCH,
      width: {
        lg: 33.33,
        md: 33.33,
        sm: 50,
        xs: 50,
      },
      rules: [
        {
          required: false,
        },
      ],
      label: 'Bread',
      otherprops: {
        onChange: (value: boolean) => {
          if (!value) {
            form.setFieldValue('breadValueInKg', null);
          }
        },
      },
    },
    width < 540 && {
      name: 'swarming',
      type: FORM_FIELD.SWITCH,
      width: {
        lg: 33.33,
        md: 33.33,
        sm: 100,
        xs: 100,
      },
      rules: [
        {
          required: false,
        },
      ],
      label: 'Swarming',
    },
    width < 540 && {
      name: 'foodBread',
      type: FORM_FIELD.SWITCH,
      width: {
        lg: 33.33,
        md: 33.33,
        sm: 50,
        xs: 50,
      },
      rules: [
        {
          required: false,
        },
      ],
      label: 'Bread',
      otherprops: {
        onChange: (value: boolean) => {
          if (!value) {
            form.setFieldValue('breadValueInKg', null);
          }
        },
      },
    },
    {
      name: 'foodSyrup',
      type: FORM_FIELD.SWITCH,
      width: {
        lg: 33.33,
        md: 33.33,
        sm: 50,
        xs: 50,
      },
      rules: [
        {
          required: false,
        },
      ],
      label: 'Syrup',
      otherprops: {
        onChange: (value: boolean) => {
          if (!value) {
            form.setFieldValue('syrupValueInKg', null);
          }
        },
      },
    },
    width > 540 && {
      name: 'swarming',
      type: FORM_FIELD.SWITCH,
      width: {
        lg: 33.33,
        md: 33.33,
        sm: 100,
        xs: 100,
      },
      rules: [
        {
          required: false,
        },
      ],
      label: 'Swarming',
    },
    {
      name: 'breadValueInKg',
      type: FORM_FIELD.NUMBER,
      width: {
        lg: 33.33,
        md: 33.33,
        sm: 50,
        xs: 50,
      },
      dependencies: ['foodBread'],
      rules: [
        ({ getFieldValue }: any) => ({
          validator(_: any, value: any) {
            if (!value && getFieldValue('foodBread')) {
              return Promise.reject('Field Is Required');
            }
            return Promise.resolve();
          },
        }),
      ],
      placeholder: 'Bread (Kg)',
      otherprops: {
        min: 0,
        max: 50,
        disabled: !foodBread,
      },
    },
    {
      name: 'syrupValueInKg',
      type: FORM_FIELD.NUMBER,
      width: {
        lg: 33.33,
        md: 33.33,
        sm: 50,
        xs: 50,
      },
      dependencies: ['foodSyrup'],
      rules: [
        ({ getFieldValue }: any) => ({
          validator(_: any, value: any) {
            if (!value && getFieldValue('foodSyrup')) {
              return Promise.reject('Field Is Required');
            }
            return Promise.resolve();
          },
        }),
      ],
      placeholder: 'Syrup (Kg)',
      otherprops: {
        min: 0,
        max: 50,
        disabled: !foodSyrup,
      },
    },
    {
      name: 'notes',
      type: FORM_FIELD.TEXT_AREA,
      width: {
        lg: 100,
        md: 100,
        sm: 100,
        xs: 100,
      },
      rows: 3,
      rules: [
        {
          required: true,
          message: 'Field Is Required',
        },
      ],
      placeholder: 'Notes',
    },
  ];

  return fields;
};
