import { FORM_FIELD } from '../../constants/enums/formEnums';
import { FormField } from '../../interfaces/FormInterfaces';

export const teamMemberFormFields: FormField[] = [
  {
    name: 'name',
    type: FORM_FIELD.INPUT,
    rules: [
      {
        required: true,
        message: 'Please add member name',
      },
      {
        max: 30,
        message: 'Maximum 30 characters',
      },
    ],
    placeholder: 'Name',
  },
  {
    name: 'surname',
    type: FORM_FIELD.INPUT,
    rules: [
      {
        required: true,
        message: 'Please add member surname',
      },
      {
        max: 30,
        message: 'Maximum 30 characters',
      },
    ],
    placeholder: 'Surname',
  },
  {
    name: 'description',
    type: FORM_FIELD.INPUT,
    rules: [
      {
        required: true,
        message: 'Please add member description',
      },
    ],
    placeholder: 'Description',
  },
];
