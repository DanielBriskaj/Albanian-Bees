import { FORM_FIELD } from '../../constants/enums/formEnums';
import { FormField } from '../../interfaces/FormInterfaces';

export const loginFormFields: FormField[] = [
  {
    name: 'username',
    type: FORM_FIELD.INPUT,
    rules: [
      {
        required: true,
        message: 'Please add your username',
      },
    ],
    placeholder: 'Username',
  },
  {
    name: 'password',
    type: FORM_FIELD.PASSWORD,
    rules: [
      {
        required: true,
        message: 'Please add your password',
      },
      {
        min: 5,
        message: 'Password must contain at least 5 characters',
      },
    ],
    placeholder: 'Password',
  },
];
