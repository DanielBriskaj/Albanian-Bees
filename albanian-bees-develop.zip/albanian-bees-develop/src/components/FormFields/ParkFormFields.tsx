import { FORM_FIELD } from '../../constants/enums/formEnums';
import { FormField } from '../../interfaces/FormInterfaces';

export const parkFormFields: FormField[] = [
  {
    name: 'name',
    type: FORM_FIELD.INPUT,
    rules: [
      {
        required: true,
        message: 'Please add park name',
      },
      {
        max: 30,
        message: 'Maximum 30 characters',
      },
    ],
    placeholder: 'Name',
  },
  {
    name: 'description',
    type: FORM_FIELD.INPUT,
    rules: [
      {
        required: true,
        message: 'Please add park description',
      },
    ],
    placeholder: 'Description',
  },
];
