import { Breadcrumb, Form, Modal } from 'antd';
import React, { useEffect, useState } from 'react';
import notificationThrower from '../../helpers/notificationThrower';
import { HiveTransferCreate } from '../../interfaces/Transfers';
import { useLazyGetAllHivesQuery } from '../../redux/slices/beeHive/beeHiveApi';
import { useGetAllParksQuery } from '../../redux/slices/park/parkApi';
import { useTransferHivesMutation } from '../../redux/slices/transfers/transfersApi';
import { transferHivesFormFields } from '../FormFields/TransferHivesFormFields';
import FormRender from '../FormRender';

interface ModalProps {
  openForm: boolean;
  setOpenForm: React.Dispatch<React.SetStateAction<boolean>>;
}

export const TransferModal: React.FC<ModalProps> = ({
  openForm,
  setOpenForm,
}) => {
  const [form] = Form.useForm();
  const sourcePark = Form.useWatch('fromParkId', form);
  const [parkOptions, setParkOptions] = useState<
    Array<{ value: number; label: string }>
  >([]);
  const [hiveOptions, setHiveOptions] = useState<
    Array<{ value: number; label: string }>
  >([]);
  const [createTransfer, { isLoading }] = useTransferHivesMutation();
  const [getHives, { isFetching }] = useLazyGetAllHivesQuery();
  const { data: parkData } = useGetAllParksQuery();

  const handleSubmit = (data: HiveTransferCreate) => {
    createTransfer(data)
      .unwrap()
      .then(() => {
        notificationThrower({
          type: 'success',
          title: 'Hive Transferred Successfully',
        });
        setOpenForm(false);
      })
      .catch(() => {
        notificationThrower({
          type: 'error',
          title: 'Failed To Transfer Hive',
        });
      });
  };

  useEffect(() => {
    sourcePark &&
      getHives({
        park: parkOptions?.find(park => park?.value === sourcePark)?.label,
        page: 0,
        size: 500,
      })
        .unwrap()
        .then(payload => {
          setHiveOptions(
            payload?.content?.map(hive => {
              return {
                value: hive?.id,
                label: hive?.hiveIdentifierValue,
              };
            }),
          );
        });
  }, [sourcePark]);

  useEffect(() => {
    form.setFieldValue('toParkId', '');
    if (parkData) {
      setParkOptions(
        parkData?.map(park => {
          return {
            value: park?.id,
            label: park?.name,
            disabled: park?.id === sourcePark,
          };
        }),
      );
    }
  }, [parkData, sourcePark]);

  return (
    <Modal
      title={
        <Breadcrumb>
          <Breadcrumb.Item>Transfers</Breadcrumb.Item>
          <Breadcrumb.Item>Create</Breadcrumb.Item>
        </Breadcrumb>
      }
      centered
      open={openForm}
      footer={null}
      onCancel={() => {
        setOpenForm(false);
      }}
      className={'transfer-modal'}
    >
      <FormRender
        name={'transfer-form'}
        onFinish={handleSubmit}
        formFields={transferHivesFormFields(parkOptions, hiveOptions)}
        loading={isLoading}
        submitButton={'Create'}
        className={'transfer-form-render'}
        onCancel={() => {
          setOpenForm(false);
        }}
        form={form}
      />
    </Modal>
  );
};
