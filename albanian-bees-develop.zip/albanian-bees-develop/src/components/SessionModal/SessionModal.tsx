import { Breadcrumb, Form, Modal, Spin } from 'antd';
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router';
import notificationThrower from '../../helpers/notificationThrower';
import { NumberOptionsProps } from '../../interfaces/FormInterfaces';
import { useGetAllParksQuery } from '../../redux/slices/park/parkApi';
import { useCreateSessionMutation } from '../../redux/slices/sessions/sessionsApi';
import { useLazyGetWeatherQuery } from '../../redux/slices/sessions/weatherApi';
import { useGetAllMembersQuery } from '../../redux/slices/teamMember/teamMemberApi';
import { sessionFormFields } from '../FormFields/SessionFormFields';
import FormRender from '../FormRender';

interface BeeHiveModalProps {
  openForm: boolean;
  setOpenForm: React.Dispatch<React.SetStateAction<boolean>>;
}

export const SessionModal: React.FC<BeeHiveModalProps> = ({
  openForm,
  setOpenForm,
}) => {
  const navigate = useNavigate();
  const [form] = Form.useForm();
  const selectedPark = Form.useWatch('park', form);

  const [parkOptions, setParkOptions] = useState<NumberOptionsProps[]>([]);
  const [memberOptions, setMemberOptions] = useState<NumberOptionsProps[]>([]);
  const [error, setError] = useState<boolean>(false);

  const [createSession, { isLoading }] = useCreateSessionMutation();
  const [getWeather, { data: weatherData, isFetching: weatherLoading }] =
    useLazyGetWeatherQuery();
  const { data: parkData = [] } = useGetAllParksQuery();
  const { data: memberData = [] } = useGetAllMembersQuery();

  useEffect(() => {
    setParkOptions(
      parkData?.map(park => {
        return {
          value: park?.id,
          label: park?.name,
        };
      }),
    );
  }, [parkData]);

  useEffect(() => {
    setMemberOptions(
      memberData?.map(member => {
        return {
          value: member?.id,
          label: member?.name + ' ' + member?.surname,
        };
      }),
    );
  }, [memberData]);

  useEffect(() => {
    selectedPark &&
      getWeather(selectedPark)
        .unwrap()
        .catch(() => {
          notificationThrower({
            type: 'error',
            title: 'Failed To Get Weather Data',
          });
        });
  }, [selectedPark]);

  const handleSubmit = (formData: any) => {
    setError(false);
    if (weatherLoading) {
      setError(true);
    } else {
      const teamMember = formData?.teamMember?.map((member: number) => {
        return {
          id: member,
        };
      });
      const transformedData = {
        ...formData,
        park: {
          id: formData?.park,
        },
        teamMember,
        weather: {
          description: weatherData?.description,
          humidity: weatherData?.humidity,
          temperature: weatherData?.temperature,
          wind: weatherData?.windSpeed,
        },
      };

      createSession(transformedData)
        .unwrap()
        .then(payload => {
          notificationThrower({
            type: 'success',
            title: 'Session Created Successfully',
          });
          setOpenForm(false);
          navigate(`/sessions/${payload?.id}`);
        })
        .catch(() => {
          notificationThrower({
            type: 'error',
            title: 'Failed To Create Session',
          });
        });
    }
  };

  return (
    <Modal
      title={
        <Breadcrumb>
          <Breadcrumb.Item>Session</Breadcrumb.Item>
          <Breadcrumb.Item>{'Create'}</Breadcrumb.Item>
        </Breadcrumb>
      }
      centered
      open={openForm}
      footer={null}
      onCancel={() => {
        setOpenForm(false);
      }}
      className={'session-modal'}
    >
      <FormRender
        name={'session-form'}
        onFinish={handleSubmit}
        formFields={sessionFormFields(parkOptions, memberOptions)}
        loading={isLoading}
        submitButton={'Create'}
        className={'session-form-render'}
        onCancel={() => {
          setOpenForm(false);
        }}
        form={form}
        formEnd={
          <div className="weather-container">
            <div className="header">Weather:</div>
            {!selectedPark && (
              <div className="no-park">Select a park to get weather info.</div>
            )}
            {weatherData && !weatherLoading ? (
              <div className="info">
                <div className="row">
                  <div className="city"> City: {weatherData?.city}</div>
                  <div className="temp">
                    Temperature: {weatherData?.temperature}
                  </div>
                </div>
                <div className="row">
                  <div className="desc">
                    {' '}
                    Description: {weatherData?.description}
                  </div>
                  <div className="humidity">
                    Humidity: {weatherData?.humidity}
                  </div>
                </div>
                <div className="row">
                  <div className="wind">Wind: {weatherData?.windSpeed} m/s</div>
                </div>
              </div>
            ) : weatherLoading ? (
              <div className="loading">
                <Spin />
                {error && (
                  <div className="error">Please Wait For Weather Info!</div>
                )}
              </div>
            ) : (
              <></>
            )}
          </div>
        }
      />
    </Modal>
  );
};
