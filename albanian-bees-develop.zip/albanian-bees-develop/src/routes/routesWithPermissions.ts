import { ROLES } from '../constants/enums/roles';

interface stringToArray {
  [key: string]: Array<string>;
}

const routesWithPermissions: stringToArray = {
  '/': [ROLES.ADMIN],
  '/login': [],
  '/team-members': [ROLES.ADMIN],
  '/hives': [ROLES.ADMIN],
  '/sessions': [ROLES.ADMIN],
  '/sessions/:id': [ROLES.ADMIN],
  '/transfers': [ROLES.ADMIN],
};

export default routesWithPermissions;
