import React from 'react';
import CostumLoadable from '../components/Loaders/CostumLoadable';

type Route = {
  caseSensitive?: boolean;
  children?: Route[];
  element?: React.ReactNode;
  path?: string;
};

const ParksLoader = () => import('../pages/Parks');
const LoginLoader = () => import('../pages/Login');
const TeamMembersLoader = () => import('../pages/TeamMembers');
const BeeHivesLoader = () => import('../pages/BeeHives');
const SessionsLoader = () => import('../pages/Sessions');
const SessionDetailsLoader = () => import('../pages/SessionDetails');
const TransfersLoader = () => import('../pages/Transfers');

const routes: Route[] = [
  {
    path: '/',
    element: <CostumLoadable loader={ParksLoader} path={'/'} />,
  },
  {
    path: '/login',
    element: <CostumLoadable loader={LoginLoader} path={'/login'} />,
  },
  {
    path: '/team-members',
    element: (
      <CostumLoadable loader={TeamMembersLoader} path={'/team-members'} />
    ),
  },
  {
    path: '/hives',
    element: <CostumLoadable loader={BeeHivesLoader} path={'/hives'} />,
  },
  {
    path: '/sessions',
    element: <CostumLoadable loader={SessionsLoader} path={'/sessions'} />,
  },
  {
    path: '/sessions/:id',
    element: (
      <CostumLoadable loader={SessionDetailsLoader} path={'/sessions/:id'} />
    ),
  },
  {
    path: '/transfers',
    element: <CostumLoadable loader={TransfersLoader} path={'/transfers'} />,
  },
];

export default routes;
