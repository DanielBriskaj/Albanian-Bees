import React, { useEffect } from 'react';
import { useNavigate, useRoutes } from 'react-router-dom';
import { tokenExpiry } from './helpers/getUserInfo';
import Dashboard from './layouts/Dashboard';
import routes from './routes/routes';

function App() {
  const navigate = useNavigate();
  const expire = tokenExpiry();
  const renderRoutes = useRoutes(routes);

  const handleLogOut = () => {
    localStorage.clear();
    navigate('/login');
  };

  useEffect(() => {
    window.scrollTo(0, 0);
    if (expire! * 1000 < new Date().getTime()) {
      handleLogOut();
    }
  }, [window.location.pathname]);
  return (
    <div className="App">
      <Dashboard>{renderRoutes}</Dashboard>
    </div>
  );
}

export default App;
