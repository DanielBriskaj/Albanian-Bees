import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Layout, Menu } from 'antd';
import Logo from '../../assets/images/logo.png';
import { ReactComponent as SignOut } from '../../assets/svgIcons/box-arrow-left.svg';
import { ReactComponent as CloseX } from '../../assets/svgIcons/x-lg.svg';
import { ItemType } from 'antd/lib/menu/hooks/useItems';

interface CustomSiderProps {
  collapsed: boolean;
  setCollapsed: React.Dispatch<React.SetStateAction<boolean>>;
  siderItems: ItemType[];
}

const CustomSider: React.FC<CustomSiderProps> = ({
  collapsed,
  setCollapsed,
  siderItems,
}) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { Sider } = Layout;
  const { innerWidth: width } = window;

  const selectedMenu = location?.pathname?.includes('sessions')
    ? '/sessions'
    : location?.pathname;

  const handleLogout = () => {
    localStorage.clear();
    navigate('/login');
  };

  return (
    <Sider
      collapsible
      collapsed={collapsed}
      onCollapse={value => setCollapsed(value)}
      width={`${width > 500 ? '300px' : '100%'}`}
      className="sidebar"
      collapsedWidth={width > 500 ? '80' : '0'}
    >
      <section>
        <div className="logo">
          {collapsed ? (
            <img src={Logo} alt={'logoCollapsed'} />
          ) : (
            <span className="uncollapsed-logo">
              <img src={Logo} alt={'Logo'} />
            </span>
          )}
        </div>
        {width < 500 && (
          <CloseX
            className="close-svg"
            onClick={() => setCollapsed(!collapsed)}
          />
        )}
        <Menu
          className="route-items"
          defaultSelectedKeys={[selectedMenu]}
          mode="inline"
          items={siderItems}
        />
      </section>
      <section className="sidebar-footer">
        <Menu
          mode="inline"
          items={[
            {
              key: '7',
              onClick: handleLogout,
              icon: <SignOut className="exit-svg" />,
              label: 'Sign-Out',
            },
          ]}
        />
      </section>
    </Sider>
  );
};

export default CustomSider;
