/* eslint-disable react-hooks/rules-of-hooks */
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layout } from 'antd';
import CustomSider from './CustomSider';
import { MenuItem, renderMenuItem } from '../../helpers/renderMenuItems';
import { ReactComponent as Pin } from '../../assets/svgIcons/geo-alt-fill.svg';
import { ReactComponent as Hive } from '../../assets/svgIcons/archive-fill.svg';
import { ReactComponent as Search } from '../../assets/svgIcons/search.svg';
import { ReactComponent as Users } from '../../assets/svgIcons/people-fill.svg';
import { ReactComponent as Team } from '../../assets/svgIcons/businessman-team.svg';
import { ReactComponent as DoubleArrow } from '../../assets/svgIcons/arrow-left-right.svg';

import Header from './Header';

export const Dashboard = ({ children }: any) => {
  const { innerWidth: width } = window;
  const { Content } = Layout;
  const navigate = useNavigate();
  const [siderItems, setsiderItems] = useState<any>(null);
  const [collapsed, setCollapsed] = useState<boolean>(width < 500 ?? false);
  const token = localStorage.getItem('idToken');

  const menuItems: MenuItem[] = [
    renderMenuItem(
      'Parks',
      '/',
      () => {
        navigate('/');
        width < 500 && setCollapsed(true);
      },
      <Pin className="menu-icons" />,
    ),
    renderMenuItem(
      'Hives',
      '/hives',
      () => {
        navigate('/hives');
        width < 500 && setCollapsed(true);
      },
      <Hive className="menu-icons" />,
    ),
    renderMenuItem(
      'Sessions',
      '/sessions',
      () => {
        navigate('/sessions');
        width < 500 && setCollapsed(true);
      },
      <Search className="menu-icons" />,
    ),
    renderMenuItem(
      'Transfers',
      '/transfers',
      () => {
        navigate('/transfers');
        width < 500 && setCollapsed(true);
      },
      <DoubleArrow className="menu-icons" />,
    ),
    renderMenuItem(
      'Team Members',
      '/team-members',
      () => {
        navigate('/team-members');
        width < 500 && setCollapsed(true);
      },
      <Team className="menu-icons" />,
    ),
    renderMenuItem(
      'Users',
      '/users',
      () => {
        navigate('/users');
        width < 500 && setCollapsed(true);
      },
      <Users className="menu-icons" />,
    ),
  ];

  useEffect(() => {
    if (!token) {
      navigate('/login');
    } else {
      setsiderItems([...menuItems]);
    }
  }, [token]);
  if (window.location.pathname.includes('login')) {
    return children;
  } else {
    return (
      <Layout style={{ minHeight: '100vh' }} className="dashboard">
        <CustomSider
          collapsed={collapsed}
          setCollapsed={e => setCollapsed(e)}
          siderItems={siderItems}
        />

        <Layout
          className={`site-layout ${
            collapsed ? 'site-layout-collapsed' : 'site-layout-uncollapsed'
          }`}
        >
          {width < 500 && (
            <Header collapsed={collapsed} setCollapsed={setCollapsed} />
          )}
          <Content style={{ overflow: 'auto' }}>
            <div className="site-layout-background">{children}</div>
          </Content>
        </Layout>
      </Layout>
    );
  }
};
