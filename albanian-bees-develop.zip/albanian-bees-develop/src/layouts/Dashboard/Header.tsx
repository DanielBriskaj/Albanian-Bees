import React from 'react';
import { ReactComponent as MenuToggle } from '../../assets/svgIcons/list.svg';

interface HeaderProps {
  collapsed: boolean;
  setCollapsed: React.Dispatch<React.SetStateAction<boolean>>;
}

const Header: React.FC<HeaderProps> = ({ collapsed, setCollapsed }) => {
  return (
    <div
      className={`custom-layout-header ${
        collapsed ? 'collapsed-header' : 'uncollapsed-header'
      }`}
    >
      <div
        className="mobile-menu-toggle"
        onClick={() => setCollapsed(!collapsed)}
      >
        <MenuToggle className="toggle-svg" />
      </div>
    </div>
  );
};

export default Header;
