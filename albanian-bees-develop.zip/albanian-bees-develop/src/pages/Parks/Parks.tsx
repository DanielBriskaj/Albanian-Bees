import React, { useState } from 'react';
import ParkCard from '../../components/ParkCard';
import { useGetAllParksQuery } from '../../redux/slices/park/parkApi';
import { ReactComponent as Create } from '../../assets/svgIcons/plus-square-fill.svg';
import { MapContainer, Marker, Popup, TileLayer } from 'react-leaflet';
import ParkModal from '../../components/ParkModal';
import { MapSearch } from '../../helpers/mapSearch';

export const Parks: React.FC = () => {
  const [openPark, setOpenPark] = useState<number | boolean | null>(null);
  const { data = [], isFetching } = useGetAllParksQuery();

  return (
    <div className="parks-container">
      <h1 className="parks-title">Parks</h1>
      <div className="items">
        {!isFetching && data?.length === 0 ? (
          <div className="no-parks">
            <span>No Parks Available</span>
          </div>
        ) : (
          data?.map((park, index) => {
            return <ParkCard key={index} {...park} setOpenPark={setOpenPark} />;
          })
        )}
      </div>
      <div className="map-container">
        <MapContainer center={[41.3275, 19.8187]} zoom={8}>
          <MapSearch />
          <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
          {data?.map((park, index) => {
            return (
              <Marker key={index} position={[park?.latitude, park?.longitude]}>
                <Popup>
                  <h1>{park?.name}</h1> <div>{park?.description}</div>
                </Popup>
              </Marker>
            );
          })}
        </MapContainer>
      </div>
      <Create className="create-svg" onClick={() => setOpenPark(true)} />
      {openPark && <ParkModal openPark={openPark} setOpenPark={setOpenPark} />}
    </div>
  );
};
