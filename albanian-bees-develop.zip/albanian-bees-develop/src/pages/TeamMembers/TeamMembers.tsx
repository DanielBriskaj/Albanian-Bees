import React, { useState } from 'react';
import { useGetAllMembersQuery } from '../../redux/slices/teamMember/teamMemberApi';
import { ReactComponent as Create } from '../../assets/svgIcons/plus-square-fill.svg';
import TeamMemberCard from '../../components/TeamMemberCard';
import TeamMemberModal from '../../components/TeamMemberModal';

export const TeamMembers: React.FC = () => {
  const [openMember, setOpenMember] = useState<number | boolean | null>(null);
  const { data, isFetching } = useGetAllMembersQuery();
  return (
    <div className="team-member-container">
      <h1 className="title">Team Members</h1>
      <div className="items">
        {!isFetching && data?.length === 0 ? (
          <div className="no-team-members">
            <span>No Team Members Available</span>
          </div>
        ) : (
          data?.map((member, index) => {
            return (
              <TeamMemberCard
                key={index}
                {...member}
                setOpenMember={setOpenMember}
              />
            );
          })
        )}
      </div>
      <Create className="create-svg" onClick={() => setOpenMember(true)} />
      {openMember && (
        <TeamMemberModal
          openMember={openMember}
          setOpenMember={setOpenMember}
        />
      )}
    </div>
  );
};
