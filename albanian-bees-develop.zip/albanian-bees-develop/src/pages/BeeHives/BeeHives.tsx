import { Spin } from 'antd';
import React, { useEffect, useState } from 'react';
import InfiniteScroll from 'react-infinite-scroller';
import { ReactComponent as Create } from '../../assets/svgIcons/plus-square-fill.svg';
import { ReactComponent as Filter } from '../../assets/svgIcons/filter.svg';
import BeeHiveCard from '../../components/BeeHiveCard';
import BeeHiveModal from '../../components/BeeHiveModal';
import FormRender from '../../components/FormRender';
import notificationThrower from '../../helpers/notificationThrower';
import { BeeHiveData, BeeHivesQuery } from '../../interfaces/BeeHive';
import { useLazyGetAllHivesQuery } from '../../redux/slices/beeHive/beeHiveApi';
import { FilterFields } from './FilterFields';

export const BeeHives: React.FC = () => {
  const { innerWidth: width } = window;
  const [openHive, setOpenHive] = useState<number | boolean | null>(null);
  const [page, setPage] = useState<number>(0);
  const [hasMore, setHasMore] = useState<boolean>(true);
  const [hivesArray, setHivesArray] = useState<BeeHiveData[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [medicationValue, setMedicationValue] = useState<string>('');
  const [queenValue, setQueenValue] = useState<string>('');
  const [park, setPark] = useState<string>('');
  const [hiveIdentifierValue, setHiveIdentifierValue] = useState<string>('');
  const [foodBread, setFoodBread] = useState<boolean | ''>('');
  const [foodSyrup, setFoodSyrup] = useState<boolean | ''>('');
  const [frames, setFrames] = useState<number>();
  const [openFilters, setOpenFilters] = useState<boolean>(false);

  const query: BeeHivesQuery = {
    page,
    size: 10,
    frames,
    medicationValue,
    queenValue,
    park,
    hiveIdentifierValue,
    foodBread,
    foodSyrup,
    order: ['id', 'desc'],
  };

  const [getAllHives, { isFetching }] = useLazyGetAllHivesQuery();

  useEffect(() => {
    setHivesArray([]);
    setPage(0);
    setHasMore(true);
  }, [
    frames,
    medicationValue,
    queenValue,
    park,
    hiveIdentifierValue,
    foodBread,
    foodSyrup,
  ]);

  const loadMore = async (e: number) => {
    if (hasMore) {
      setLoading(true);
      getAllHives(query)
        .unwrap()
        .then(async payload => {
          setHivesArray([...hivesArray, ...payload?.content]);
          if (payload?.totalPages <= page + 1) {
            setHasMore(false);
          } else {
            setPage(page + 1);
          }
          setLoading(false);
        })
        .catch(() => {
          notificationThrower({
            type: 'error',
            title: 'Failed To Get Hives',
          });
          setLoading(false);
          setHasMore(false);
        });
    }
  };

  return (
    <div className="bee-hives-container">
      <div className="header">
        <h1 className="title">Bee Hives</h1>
        {width < 500 && (
          <div className="toggle" onClick={() => setOpenFilters(!openFilters)}>
            Filter <Filter className="filter-svg" />
          </div>
        )}
      </div>
      <div className="filters">
        <FormRender
          name="filters"
          formFields={FilterFields(
            setQueenValue,
            setMedicationValue,
            setFrames,
            setPark,
            setHiveIdentifierValue,
            setFoodBread,
            setFoodSyrup,
          )}
          loading={false}
          submitButton={undefined}
          className={`filters-form ${
            width < 500 && (openFilters ? 'open-filters' : 'close-filters')
          }`}
          initialValues={[
            { name: 'queenValue', value: queenValue },
            { name: 'medicationValue', value: medicationValue },
            { name: 'park', value: park },
            { name: 'foodBread', value: foodBread },
            { name: 'foodSyrup', value: foodSyrup },
          ]}
        />
      </div>
      <div>
        <InfiniteScroll
          initialLoad
          pageStart={0}
          loadMore={e => loadMore(e)}
          hasMore={!loading && hasMore}
          loader={
            <div className="loader" key={0}>
              <Spin />
            </div>
          }
          className="items"
        >
          {!isFetching && hivesArray?.length === 0 ? (
            <div className="no-bee-hives">
              <span>No Bee Hives Available</span>
            </div>
          ) : (
            hivesArray?.map((hive, index) => {
              return (
                <BeeHiveCard
                  key={index}
                  {...hive}
                  setOpenHive={setOpenHive}
                  hivesArray={hivesArray}
                  setHivesArray={setHivesArray}
                />
              );
            })
          )}
        </InfiniteScroll>
      </div>
      <Create className="create-svg" onClick={() => setOpenHive(true)} />

      {openHive && (
        <BeeHiveModal
          openHive={openHive}
          setOpenHive={setOpenHive}
          setHivesArray={setHivesArray}
          hivesArray={hivesArray}
        />
      )}
    </div>
  );
};
