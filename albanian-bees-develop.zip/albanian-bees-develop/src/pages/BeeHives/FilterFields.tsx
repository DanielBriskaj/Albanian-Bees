import { debounce } from 'lodash';
import React, { useEffect, useState } from 'react';
import {
  MedicationOptions,
  QueenOptions,
} from '../../components/FormFields/BeeHiveFormFields';
import { FORM_FIELD } from '../../constants/enums/formEnums';
import { useGetAllParksQuery } from '../../redux/slices/park/parkApi';

export const FilterFields = (
  setQueenValue: React.Dispatch<React.SetStateAction<string>>,
  setMedicationValue: React.Dispatch<React.SetStateAction<string>>,
  setFrames: React.Dispatch<React.SetStateAction<number | undefined>>,
  setPark: React.Dispatch<React.SetStateAction<string>>,
  setHiveIdentifierValue: React.Dispatch<React.SetStateAction<string>>,
  setFoodBread: React.Dispatch<React.SetStateAction<boolean | ''>>,
  setFoodSyrup: React.Dispatch<React.SetStateAction<boolean | ''>>,
) => {
  const [parkOptions, setParkOptions] = useState<
    Array<{ value: string; label: string }>
  >([{ value: '', label: 'All' }]);
  const { data: parkData = [] } = useGetAllParksQuery();

  const handleSearchFrames = (e: number) => {
    setFrames(e);
  };
  const debounceSearchFrames = debounce(handleSearchFrames, 500);

  const handleSearchSN = (e: React.ChangeEvent<HTMLInputElement>) => {
    setHiveIdentifierValue(e?.target?.value);
  };
  const debounceSearchSN = debounce(handleSearchSN, 500);

  useEffect(() => {
    setParkOptions([
      ...parkOptions,
      ...parkData?.map(park => {
        return {
          value: park?.name,
          label: park?.name,
        };
      }),
    ]);
  }, [parkData]);

  const fields = [
    {
      name: 'park',
      type: FORM_FIELD.ANTD_SELECT,
      rules: [],
      placeholder: 'Park',
      options: parkOptions,
      otherprops: {
        onChange: (e: string) => setPark(e),
      },
    },
    {
      name: 'frames',
      type: FORM_FIELD.NUMBER,
      rules: [],
      placeholder: 'Frames',
      otherprops: {
        min: 0,
        onChange: debounceSearchFrames,
      },
    },
    {
      name: 'hiveIdentifierValue',
      type: FORM_FIELD.INPUT,
      rules: [],
      placeholder: 'Hive SN',
      otherprops: {
        onChange: debounceSearchSN,
      },
    },
    {
      name: 'queenValue',
      type: FORM_FIELD.ANTD_SELECT,
      rules: [],
      placeholder: 'Queen',
      options: QueenOptions,
      otherprops: {
        onChange: (e: string) => setQueenValue(e),
      },
    },
    {
      name: 'medicationValue',
      type: FORM_FIELD.ANTD_SELECT,
      rules: [],
      placeholder: 'Medication',
      options: MedicationOptions,
      otherprops: {
        onChange: (e: string) => setMedicationValue(e),
      },
    },
    {
      name: 'foodBread',
      type: FORM_FIELD.ANTD_SELECT,
      rules: [],
      placeholder: 'Bread',
      options: [
        { value: '', label: 'All' },
        { value: true, label: 'With Bread' },
        { value: false, label: 'Without Bread' },
      ],
      otherprops: {
        onChange: (e: boolean) => setFoodBread(e),
      },
    },
    {
      name: 'foodSyrup',
      type: FORM_FIELD.ANTD_SELECT,
      rules: [],
      placeholder: 'Syrup',
      options: [
        { value: '', label: 'All' },
        { value: true, label: 'With Syrup' },
        { value: false, label: 'Without Syrup' },
      ],
      otherprops: {
        onChange: (e: boolean) => setFoodSyrup(e),
      },
    },
  ];
  return fields;
};
