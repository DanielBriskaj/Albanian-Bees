export { BeeHives as default } from './BeeHives';
