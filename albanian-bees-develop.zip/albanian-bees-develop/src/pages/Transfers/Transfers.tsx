import { Table } from 'antd';
import React, { useEffect, useState } from 'react';
import { ReactComponent as Create } from '../../assets/svgIcons/plus-square-fill.svg';
import { ReactComponent as Filter } from '../../assets/svgIcons/filter.svg';
import { transferColumns } from './tableColumns';
import { HiveTransferQuery } from '../../interfaces/Transfers';
import TransferModal from '../../components/TransferModal';
import { useLazyGetTransfersQuery } from '../../redux/slices/transfers/transfersApi';
import { format, parseISO } from 'date-fns';
import FormRender from '../../components/FormRender';
import { TransferFilters } from './TransferFilters';

export const Transfers: React.FC = () => {
  const { innerWidth: width } = window;
  const [page, setPage] = useState<number>(0);
  const [size, setSize] = useState<number>(10);
  const [createdAt, setCreatedAt] = useState<string>('');
  const [fromPark, setFromPark] = useState<string>('');
  const [toPark, setToPark] = useState<string>('');
  const [openForm, setOpenForm] = useState<boolean>(false);
  const [tableData, setTableData] = useState<any>([]);
  const [totalItems, setTotalItems] = useState<number>(0);
  const [openFilters, setOpenFilters] = useState<boolean>(false);

  const query: HiveTransferQuery = {
    page,
    size,
    createdAt,
    fromPark,
    toPark,
    order: ['id', 'desc'],
  };

  const [getTransfers, { data, isFetching }] = useLazyGetTransfersQuery();

  useEffect(() => {
    getTransfers(query);
  }, [page, size, createdAt, fromPark, toPark]);

  useEffect(() => {
    if (data) {
      setTableData(
        data?.content?.map(transfer => ({
          key: transfer?.id,
          id: transfer?.id,
          source: transfer?.fromPark?.name,
          date: format(parseISO(transfer?.createdAt), 'dd-MM-yyyy'),
          destination: transfer?.toPark?.name,
          hiveId: transfer?.beeHiveToTransfer?.hiveIdentifierValue,
          description: transfer?.description,
        })),
      );
    }
    setTotalItems(data?.totalItems ?? 0);
  }, [data]);

  const handlePageChange = (page: any, pageSize: any) => {
    setPage(page - 1);
    setSize(pageSize);
  };
  const handleShowSizeChange = (size: number) => {
    setSize(size);
  };

  return (
    <div className="transfers-container">
      <div className="header">
        <h1 className="title">Transfers</h1>
        {width < 500 && (
          <div className="toggle" onClick={() => setOpenFilters(!openFilters)}>
            Filter <Filter className="filter-svg" />
          </div>
        )}
      </div>
      <div className="filters">
        <FormRender
          name="filters"
          formFields={TransferFilters(setCreatedAt, setFromPark, setToPark)}
          loading={false}
          submitButton={undefined}
          className={`filters-form ${
            width < 500 && (openFilters ? 'open-filters' : 'close-filters')
          }`}
          initialValues={[
            { name: 'source', value: fromPark },
            { name: 'destination', value: toPark },
          ]}
        />
      </div>
      <div className="table-container">
        <Table
          columns={transferColumns}
          dataSource={tableData}
          scroll={{ x: true }}
          loading={isFetching}
          pagination={{
            total: totalItems,
            onChange: handlePageChange,
            onShowSizeChange: handleShowSizeChange,
            showSizeChanger: true,
          }}
        />
      </div>
      <Create className="create-svg" onClick={() => setOpenForm(true)} />
      {openForm && (
        <TransferModal openForm={openForm} setOpenForm={setOpenForm} />
      )}
    </div>
  );
};
