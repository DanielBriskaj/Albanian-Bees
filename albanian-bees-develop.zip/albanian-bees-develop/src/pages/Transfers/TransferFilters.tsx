import { DatePickerProps } from 'antd';
import React, { useEffect, useState } from 'react';
import { FORM_FIELD } from '../../constants/enums/formEnums';
import { useGetAllParksQuery } from '../../redux/slices/park/parkApi';

export const TransferFilters = (
  setCreatedAt: React.Dispatch<React.SetStateAction<string>>,
  setFromPark: React.Dispatch<React.SetStateAction<string>>,
  setToPark: React.Dispatch<React.SetStateAction<string>>,
) => {
  const [parkOptions, setParkOptions] = useState<
    Array<{ value: string; label: string }>
  >([{ value: '', label: 'All' }]);
  const { data: parkData } = useGetAllParksQuery();

  const handleSearchCreatedAt: DatePickerProps['onChange'] = (
    _,
    dateString,
  ) => {
    setCreatedAt(dateString);
  };

  useEffect(() => {
    if (parkData) {
      setParkOptions([
        ...parkOptions,
        ...parkData?.map(park => {
          return {
            value: park?.name,
            label: park?.name,
          };
        }),
      ]);
    }
  }, [parkData]);

  const fields = [
    {
      name: 'source',
      type: FORM_FIELD.ANTD_SELECT,
      rules: [],
      placeholder: 'Source',
      options: parkOptions,
      otherprops: {
        onChange: (e: string) => setFromPark(e),
      },
    },
    {
      name: 'destination',
      type: FORM_FIELD.ANTD_SELECT,
      rules: [],
      placeholder: 'Destination',
      options: parkOptions,
      otherprops: {
        onChange: (e: string) => setToPark(e),
      },
    },
    {
      name: 'createdAt',
      type: FORM_FIELD.DATE,
      rules: [],
      placeholder: 'Created At',
      otherprops: {
        onChange: handleSearchCreatedAt,
      },
    },
  ];
  return fields;
};
