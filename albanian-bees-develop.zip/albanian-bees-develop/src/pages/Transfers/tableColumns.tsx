import { Modal, Tooltip } from 'antd';
import React from 'react';

export const transferColumns = [
  {
    title: 'ID',
    dataIndex: 'id',
    key: 'id',
    ellipsis: {
      showTitle: false,
    },
    render: (id: number) => (
      <Tooltip placement="topLeft" title={id}>
        {id}
      </Tooltip>
    ),
  },
  {
    title: 'Source',
    dataIndex: 'source',
    key: 'source',
    ellipsis: {
      showTitle: false,
    },
    render: (source: string) => (
      <Tooltip placement="topLeft" title={source}>
        <div className="table-cell"> {source}</div>
      </Tooltip>
    ),
  },
  {
    title: 'Destination',
    dataIndex: 'destination',
    key: 'destination',
    ellipsis: {
      showTitle: false,
    },
    render: (destination: string) => (
      <Tooltip placement="topLeft" title={destination}>
        <div className="table-cell"> {destination}</div>
      </Tooltip>
    ),
  },
  {
    title: 'Hive SN',
    dataIndex: 'hiveId',
    key: 'hiveId',
    ellipsis: {
      showTitle: false,
    },
    render: (hiveId: string) => (
      <Tooltip placement="topLeft" title={hiveId}>
        <div className="table-cell"> {hiveId}</div>
      </Tooltip>
    ),
  },
  {
    title: 'Date',
    dataIndex: 'date',
    key: 'date',
    ellipsis: {
      showTitle: false,
    },
    render: (date: string) => (
      <Tooltip placement="topLeft" title={date}>
        <div className="table-cell"> {date}</div>
      </Tooltip>
    ),
  },
  {
    title: 'Description',
    dataIndex: 'description',
    key: 'description',
    ellipsis: {
      showTitle: false,
    },
    render: (description: string) => (
      <Tooltip placement="topLeft" title={description}>
        <div className="description"> {description}</div>
      </Tooltip>
    ),
  },
];
