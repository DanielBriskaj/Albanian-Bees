import React from 'react';
import { loginFormFields } from '../../components/FormFields/LoginFormFields';
import FormRender from '../../components/FormRender';
import { LoginData } from '../../interfaces/Auth';
import Bees from '../../assets/images/honey-bee.jpg';
import { useLoginMutation } from '../../redux/slices/auth/authApi';
import { useNavigate } from 'react-router';

export const Login: React.FC = () => {
  const navigate = useNavigate();
  const [handleLogin, { isLoading, isError }] = useLoginMutation();

  const handleSubmit = (data: LoginData) => {
    handleLogin(data)
      .unwrap()
      .then(payload => {
        const token = payload?.jwt;
        localStorage.setItem('idToken', token);
        navigate('/');
      });
  };

  return (
    <div className="login-container">
      <img className="image-container" src={Bees} />
      <div className="login-wrapper">
        <div className="title">
          <h2>Welcome Back</h2>
        </div>

        <FormRender
          name={'login-form'}
          onFinish={handleSubmit}
          formFields={loginFormFields}
          loading={isLoading}
          submitButton={'Login'}
          className={'login-form-render'}
          errorMessage={isError ? 'Incorrect Username Or Password' : ''}
        />
      </div>
    </div>
  );
};
