import React from 'react';
import { useNavigate } from 'react-router-dom';
import ForbidenIcon from '../assets/images/403forbiden.png';
import { getUserRole } from '../helpers/getUserInfo';

const Forbiden: React.FC = () => {
  const navigate = useNavigate();
  const role = getUserRole();

  const handleRedirect = () => {
    role ? navigate('/') : navigate('/login');
  };

  return (
    <div className="forbiden-page">
      <span className="forbiden-title">
        <img src={ForbidenIcon} alt="" /> <h1>Error 403 - Forbidden</h1>
      </span>
      <hr />
      <div className="forbiden-content">
        <p>{"You don't have permission to access this page!"}</p>
        <span>
          <button className="btn-primary" onClick={handleRedirect}>
            {role ? 'Home' : 'Login'}
          </button>
        </span>
      </div>
    </div>
  );
};

export default Forbiden;
