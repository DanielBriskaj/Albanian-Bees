import { DatePickerProps } from 'antd';
import { debounce } from 'lodash';
import React, { useEffect, useState } from 'react';
import { FORM_FIELD } from '../../constants/enums/formEnums';
import { useGetAllParksQuery } from '../../redux/slices/park/parkApi';

export const FilterFields = (
  setCreatedAt: React.Dispatch<React.SetStateAction<string>>,
  setCreatedBy: React.Dispatch<React.SetStateAction<string>>,
  setTeamMember: React.Dispatch<React.SetStateAction<string>>,
  setPark: React.Dispatch<React.SetStateAction<string>>,
) => {
  const [parkOptions, setParkOptions] = useState<
    Array<{ value: string; label: string }>
  >([{ value: '', label: 'All' }]);
  const { data: parkData } = useGetAllParksQuery();

  const handleSearchCreatedAt: DatePickerProps['onChange'] = (
    _,
    dateString,
  ) => {
    setCreatedAt(dateString);
  };

  const handleSearchCreatedBy = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCreatedBy(e?.target?.value);
  };
  const debounceSearchCreatedBy = debounce(handleSearchCreatedBy, 500);

  const handleSearchTeamMember = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTeamMember(e?.target?.value);
  };
  const debounceSearchTeamMember = debounce(handleSearchTeamMember, 500);

  useEffect(() => {
    if (parkData) {
      setParkOptions([
        ...parkOptions,
        ...parkData?.map(park => {
          return {
            value: park?.name,
            label: park?.name,
          };
        }),
      ]);
    }
  }, [parkData]);

  const fields = [
    {
      name: 'park',
      type: FORM_FIELD.ANTD_SELECT,
      rules: [],
      placeholder: 'Park',
      options: parkOptions,
      otherprops: {
        onChange: (e: string) => setPark(e),
      },
    },
    {
      name: 'teamMember',
      type: FORM_FIELD.INPUT,
      rules: [],
      placeholder: 'Team Member',
      otherprops: {
        onChange: debounceSearchTeamMember,
      },
    },
    {
      name: 'createdAt',
      type: FORM_FIELD.DATE,
      rules: [],
      placeholder: 'Created At',
      otherprops: {
        onChange: handleSearchCreatedAt,
      },
    },
    {
      name: 'createdBy',
      type: FORM_FIELD.INPUT,
      rules: [],
      placeholder: 'Created By',
      otherprops: {
        onChange: debounceSearchCreatedBy,
      },
    },
  ];
  return fields;
};
