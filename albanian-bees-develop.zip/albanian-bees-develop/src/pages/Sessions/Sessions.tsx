import { Spin } from 'antd';
import React, { useEffect, useState } from 'react';
import InfiniteScroll from 'react-infinite-scroller';
import { ReactComponent as Create } from '../../assets/svgIcons/plus-square-fill.svg';
import { ReactComponent as Filter } from '../../assets/svgIcons/filter.svg';
import FormRender from '../../components/FormRender';
import notificationThrower from '../../helpers/notificationThrower';
import { FilterFields } from './SessionFilters';
import { useLazyGetAllSessionsQuery } from '../../redux/slices/sessions/sessionsApi';
import { SessionData, SessionQuery } from '../../interfaces/Session';
import SessionCard from '../../components/SessionCard';
import SessionModal from '../../components/SessionModal';

export const Sessions: React.FC = () => {
  const { innerWidth: width } = window;
  const [page, setPage] = useState<number>(0);
  const [hasMore, setHasMore] = useState<boolean>(true);
  const [sessionsArray, setSessionsArray] = useState<SessionData[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [createdAt, setCreatedAt] = useState<string>('');
  const [createdBy, setCreatedBy] = useState<string>('');
  const [park, setPark] = useState<string>('');
  const [teamMember, setTeamMember] = useState<string>('');
  const [openForm, setOpenForm] = useState<boolean>(false);
  const [openFilters, setOpenFilters] = useState<boolean>(false);

  const query: SessionQuery = {
    page,
    size: 10,
    park,
    createdAt,
    createdBy,
    teamMember,
    order: ['id', 'desc'],
  };

  const [getAllSessions, { isFetching }] = useLazyGetAllSessionsQuery();

  useEffect(() => {
    setSessionsArray([]);
    setPage(0);
    setHasMore(true);
  }, [frames, createdAt, park, createdBy, teamMember]);

  const loadMore = async (e: number) => {
    if (hasMore) {
      setLoading(true);
      getAllSessions(query)
        .unwrap()
        .then(payload => {
          setSessionsArray([...sessionsArray, ...payload?.content]);
          if (payload?.totalPages <= page + 1) {
            setHasMore(false);
          } else {
            setPage(page + 1);
          }
          setLoading(false);
        })
        .catch(() => {
          notificationThrower({
            type: 'error',
            title: 'Failed To Get Sessions',
          });
          setLoading(false);
          setHasMore(false);
        });
    }
  };

  return (
    <div className="session-container">
      <div className="header">
        <h1 className="title">Sessions</h1>
        {width < 500 && (
          <div className="toggle" onClick={() => setOpenFilters(!openFilters)}>
            Filter <Filter className="filter-svg" />
          </div>
        )}
      </div>
      <div className="filters">
        <FormRender
          name="filters"
          formFields={FilterFields(
            setCreatedAt,
            setCreatedBy,
            setTeamMember,
            setPark,
          )}
          loading={false}
          submitButton={undefined}
          className={`filters-form ${
            width < 500 && (openFilters ? 'open-filters' : 'close-filters')
          }`}
          initialValues={[{ name: 'park', value: park }]}
        />
      </div>
      <div>
        <InfiniteScroll
          initialLoad
          pageStart={0}
          loadMore={e => loadMore(e)}
          hasMore={!loading && hasMore}
          loader={
            <div className="loader" key={0}>
              <Spin />
            </div>
          }
          className="items"
        >
          {!isFetching && sessionsArray?.length === 0 ? (
            <div className="no-sessions">
              <span>No Sessions Available</span>
            </div>
          ) : (
            sessionsArray?.map((session, index) => {
              return <SessionCard key={index} {...session} />;
            })
          )}
        </InfiniteScroll>
      </div>
      <Create className="create-svg" onClick={() => setOpenForm(true)} />
      {openForm && (
        <SessionModal openForm={openForm} setOpenForm={setOpenForm} />
      )}
    </div>
  );
};
