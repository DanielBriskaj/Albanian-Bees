import React, { useEffect, useState } from 'react';
import {
  useFinalizeSessionMutation,
  useLazyGetSingleSessionQuery,
} from '../../redux/slices/sessions/sessionsApi';
import { useParams } from 'react-router';
import { format, parseISO } from 'date-fns';
import notificationThrower from '../../helpers/notificationThrower';
import { ReactComponent as Location } from '../../assets/svgIcons/geo-alt-fill.svg';
import { ReactComponent as Calendar } from '../../assets/svgIcons/calendar-event.svg';
import { ReactComponent as User } from '../../assets/svgIcons/people-fill.svg';
import { ReactComponent as Thermometer } from '../../assets/svgIcons/thermometer-half.svg';
import { ReactComponent as Humidity } from '../../assets/svgIcons/humidity.svg';
import { ReactComponent as Smoker } from '../../assets/svgIcons/bee-smoker.svg';
import { ReactComponent as Members } from '../../assets/svgIcons/businessman-team.svg';
import { ReactComponent as Hive } from '../../assets/svgIcons/beehive.svg';
import { ReactComponent as Cloud } from '../../assets/svgIcons/cloud-fill.svg';
import { ReactComponent as Check } from '../../assets/svgIcons/check2-circle.svg';
import { ReactComponent as Wind } from '../../assets/svgIcons/wind.svg';

import { SessionStatusColor } from '../../helpers/sessionStatusColor';
import { useLazyGetHivesForSessionQuery } from '../../redux/slices/beeHive/beeHiveApi';
import { BeeHiveData } from '../../interfaces/BeeHive';
import BeeHiveModal from '../../components/BeeHiveModal';
import { SESSIONSTATUS } from '../../constants/enums/status';
import { Modal, Spin } from 'antd';

export const SessionDetails: React.FC = () => {
  const { id } = useParams();
  const { confirm } = Modal;
  const [hivesArray, setHivesArray] = useState<BeeHiveData[]>([]);
  const [openHive, setOpenHive] = useState<number | boolean | null>(null);
  const [session, setSession] = useState<{ id: number; updating: boolean }>();

  const [getSession, { data }] = useLazyGetSingleSessionQuery();
  const [getHives, { data: beeHives, isFetching }] =
    useLazyGetHivesForSessionQuery();
  const [finalizeSession, { isLoading }] = useFinalizeSessionMutation();

  useEffect(() => {
    id &&
      getSession(Number(id), true)
        .unwrap()
        .then(payload => {
          getHives(payload?.id)
            .unwrap()
            .catch(() => {
              notificationThrower({
                type: 'error',
                title: 'Failed To Get Hives Data',
              });
            });
        })
        .catch(() => {
          notificationThrower({
            type: 'error',
            title: 'Failed To Get Session Data',
          });
        });
  }, [id]);

  const handleCompleteSession = () => {
    finalizeSession(Number(id))
      .unwrap()
      .then(() => {
        notificationThrower({
          type: 'success',
          title: 'Session Completed Successfully',
        });
      })
      .catch(() => {
        notificationThrower({
          type: 'error',
          title: 'Failed To Complete Session',
        });
      });
  };

  const showConfirm = () => {
    confirm({
      title: `Are you sure you want complete this session?`,
      centered: true,
      maskClosable: true,
      onOk() {
        handleCompleteSession();
      },
      okText: 'Yes',
      cancelText: 'No',
    });
  };

  const statusColor = SessionStatusColor(data?.sessionStatus as any);

  return (
    <div className="session-details-container">
      <h1 className="title">{data?.name}</h1>
      <div className="all-details">
        <div className="info">
          <div className="park">
            <Location fill={data?.park?.colorCode} className="svg" />
            {data?.park?.name}
          </div>
          <div className="status">
            <div
              className="status-point"
              style={{
                backgroundColor: statusColor?.bg,
                color: statusColor?.color,
              }}
            ></div>
            {data?.sessionStatus}
          </div>
          <div className="date">
            <Calendar className="svg" />
            {data && format(parseISO(data?.createdAt), 'dd-MM-yyyy')}
          </div>
          <div className="creator">
            <User className="svg" /> {data?.createdBy?.username}
          </div>
          <div className="smoker">
            <Smoker className="svg" /> {data?.smoker}
          </div>
          <div className="temp">
            <Thermometer className="svg" /> {data?.weather?.temperature} °C
          </div>
          <div className="humidity">
            <Humidity className="svg" />
            {data?.weather?.humidity} %
          </div>
          <div className="description">
            <Cloud className="svg" />
            {data?.weather?.description}
          </div>
          <div className="wind">
            <Wind className="svg" />
            {data?.weather?.wind} m/s
          </div>
        </div>

        <div className="members">
          <Members className="svg" />
          {data?.teamMember?.map((member, index) => {
            return (
              <div key={index} className="member">
                {member?.name + ' ' + member?.surname}
              </div>
            );
          })}
        </div>
      </div>
      <div className="bee-hives-data">
        <div className="head">
          <div className="total-count">
            <Check className="svg" />
            <span>Controlled:</span> {data?.totalOfBeeHives}
          </div>
          {data?.sessionStatus === SESSIONSTATUS.IN_PROGRESS && (
            <button
              className="btn-primary"
              onClick={showConfirm}
              disabled={isLoading}
            >
              Complete Session
            </button>
          )}
        </div>
        {beeHives?.length === 0 && !isFetching ? (
          <div className="no-bee-hives">
            <span>No Bee Hives Available</span>
          </div>
        ) : (
          <div className="hives-data-container">
            {isFetching ? (
              <div className="spinner-container">
                <Spin />
              </div>
            ) : (
              beeHives?.map((hive, index) => {
                return (
                  <div
                    className="hive"
                    key={index}
                    onClick={() => {
                      if (data?.sessionStatus !== SESSIONSTATUS.COMPLETED) {
                        setOpenHive(hive?.id);
                        setSession({
                          id: Number(id),
                          updating: hive?.updatedForTheSession,
                        });
                      } else {
                        notificationThrower({
                          type: 'info',
                          title: 'Session Already Completed',
                          toastId: 'sessionCompleted',
                        });
                      }
                    }}
                  >
                    <Hive
                      className="svg"
                      fill={hive?.updatedForTheSession ? '#4CAF50' : '#db7c00'}
                    />
                    {hive?.hiveIdentifierValue?.slice(-3)}
                  </div>
                );
              })
            )}
          </div>
        )}
      </div>
      {openHive && (
        <BeeHiveModal
          openHive={openHive}
          setOpenHive={setOpenHive}
          hivesArray={hivesArray}
          setHivesArray={setHivesArray}
          session={session}
        />
      )}
    </div>
  );
};
