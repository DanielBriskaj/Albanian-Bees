import { MenuProps } from 'antd';

export type MenuItem = Required<MenuProps>['items'][number];

export function renderMenuItem(
  label: React.ReactNode,
  key: React.Key,
  onClick?: () => void,
  icon?: React.ReactNode,
  children?: MenuItem[],
): MenuItem {
  return {
    key,
    icon,
    children,
    label,
    onClick,
  } as MenuItem;
}
