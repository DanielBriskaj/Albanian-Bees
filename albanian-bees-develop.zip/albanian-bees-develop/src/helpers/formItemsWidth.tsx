export const formItemWidth = (providedWidth: {
  lg: number;
  md: number;
  sm: number;
  xs: number;
}) => {
  const { innerWidth: width } = window;

  switch (true) {
    case width > 820:
      return providedWidth?.lg;
    case width < 820 && width > 540:
      return providedWidth?.md;
    case width < 540 && width > 400:
      return providedWidth?.sm;
    case width < 400:
      return providedWidth?.xs;
    default:
      return providedWidth?.lg;
  }
};
