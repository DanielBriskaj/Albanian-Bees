import queryString from 'query-string';

export const myPrepareSearchParams = (options: any) => {
  if (options) {
    const query = queryString.stringify(options, {
      arrayFormat: 'comma',
    });
    return '?' + query;
  }
};
