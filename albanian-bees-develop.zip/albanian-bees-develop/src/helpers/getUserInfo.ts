import jwt_decode from 'jwt-decode';

interface DecodedToken {
  exp: number;
  iat: number;
  role: Array<string>;
  sub: string;
}
export const getUserRole = () => {
  const token = localStorage.getItem('idToken');
  if (token) {
    const decoded = jwt_decode<DecodedToken>(token);
    return decoded.role[0];
  }
};
export const getUsername = () => {
  const token = localStorage.getItem('idToken');
  if (token) {
    const decoded = jwt_decode<DecodedToken>(token);
    return decoded.sub;
  }
};

export const tokenExpiry = () => {
  const token = localStorage.getItem('idToken');
  if (token) {
    const decoded = jwt_decode<DecodedToken>(token);
    return decoded.exp;
  }
};
