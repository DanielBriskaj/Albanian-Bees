import { StatusTypes } from '../interfaces/Session';

export const SessionStatusColor = (status: StatusTypes) => {
  switch (status) {
    case 'INITIALIZED':
      return { bg: '#00000069', color: 'white' };
    case 'IN_PROGRESS':
      return { bg: '#87CEEB', color: 'white' };
    case 'COMPLETED':
      return { bg: '#4CAF50', color: 'white' };
    default:
      break;
  }
};
