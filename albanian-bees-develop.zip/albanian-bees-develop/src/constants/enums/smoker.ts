export enum SMOKER {
  CARDBOX = 'CARDBOX',
  WOOD = 'WOOD',
}
