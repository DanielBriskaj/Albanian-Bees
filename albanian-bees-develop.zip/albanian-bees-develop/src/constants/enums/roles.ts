export enum ROLES {
  ADMIN = 'Admin',
  USER = 'User',
}
