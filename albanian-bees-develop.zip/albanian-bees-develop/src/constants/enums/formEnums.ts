export enum FORM_FIELD {
  INPUT = 'input',
  PASSWORD = 'password',
  NUMBER = 'number',
  ANTD_SELECT = 'antd-select',
  CHECKBOX = 'checkbox',
  SWITCH = 'switch',
  TEXT_AREA = 'text-area',
  SECTION = 'section',
  DATE = 'date',
}
