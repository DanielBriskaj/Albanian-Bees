export enum FOOD {
  BREAD = 'BREAD',
  SYRUP = 'SYRUP',
}
