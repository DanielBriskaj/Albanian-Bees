export const SampleRegex = /[a-b]/g;
