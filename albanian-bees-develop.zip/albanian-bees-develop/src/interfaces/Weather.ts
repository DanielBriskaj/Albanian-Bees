export interface Weather {
  id: number;
  temperature: number;
  humidity: number;
  description: string;
  wind: number;
}

export interface WeatherReturn {
  city: string;
  country: string;
  description: string;
  humidity: number;
  icon: string;
  id: number;
  latitude: number;
  longitude: number;
  main: string;
  maxTemperature: number;
  minTemperature: number;
  pressure: number;
  sunrise: number;
  sunset: number;
  temperature: number;
  visibility: number;
  windDegree: number;
  windSpeed: number;
}
