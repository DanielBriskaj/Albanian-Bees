import { FormProps } from 'antd';
import { FormInstance, Rule } from 'antd/lib/form';
import { ReactNode } from 'react';

export interface FormField {
  name: string;
  type:
    | 'input'
    | 'password'
    | 'antd-select'
    | 'number'
    | 'checkbox'
    | 'switch'
    | 'text-area'
    | 'section'
    | 'date';
  rules: Rule[];
  placeholder?: string;
  label?: string;
  options?: any;
  className?: string;
  otherprops?: any;
  dependencies?: string[];
  width?: {
    lg: number;
    md: number;
    sm: number;
    xs: number;
  };
  rows?: number;
}

export interface InitialValues {
  name: string;
  value: string | number | boolean;
}
export interface FormRenderProps extends FormProps {
  formFields: FormField[];
  loading: boolean;
  formEnd?: ReactNode;
  submitButton: string | ReactNode | boolean;
  onCancel?: React.MouseEventHandler<HTMLButtonElement>;
  errorMessage?: string;
  customEndButtons?: ReactNode;
  className?: string;
  initialValues?: InitialValues[];
  form?: FormInstance<any>;
  onValuesChange?: (changedValues: any, values: any) => void;
}

export interface NumberOptionsProps {
  value: number;
  label: string;
}
