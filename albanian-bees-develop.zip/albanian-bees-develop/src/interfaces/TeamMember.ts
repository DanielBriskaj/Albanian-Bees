export interface TeamMemberData{
    id: number;
    name: string;
    surname: string;
    description: string;
}