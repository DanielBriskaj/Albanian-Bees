export interface ParkData {
  id: number;
  name: string;
  description: string;
  latitude: number;
  longitude: number;
  colorCode: string;
}
