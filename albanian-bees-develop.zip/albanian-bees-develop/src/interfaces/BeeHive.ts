import { ParkData } from './Park';
import { SessionData } from './Session';

export type QueenValueType = 'NEW' | 'OLDER_THAN_2_YEARS' | 'NO_QUEEN';
export type BreedType =
  | 'AFRICAN'
  | 'BUCKFAST'
  | 'CARNIOLAN'
  | 'CAUCASIAN'
  | 'CORDOVAN'
  | 'ITALIAN'
  | 'RUSSIAN';

export type FoodType = 'BREAD' | 'SYRUP';
export type RatingType = 'EXCELLENT' | 'GOOD' | 'NEUTRAL' | 'NOT_GOOD' | 'BAD';

export type MedicationType = 'NOZEMA' | 'VAROA' | 'OTHERS' | 'NO_MEDICATION';

export interface BeeHiveData {
  id: number;
  hiveIdentifierValue: string;
  size: number;
  frames: number;
  framesOfBees: number;
  honey: number;
  newBroot: number;
  olderBroot: number;
  empty: number;
  breadValueInKg: number;
  queenValue: QueenValueType;
  breed: BreedType;
  swarming: boolean;
  foodBread: boolean;
  foodSyrup: boolean;
  syrupValueInKg: number;
  medicationValue: MedicationType;
  activeStatus: boolean;
  notes: string;
  park: ParkData;
  session?: SessionData;
  rating: RatingType;
}

export interface BeeHivesReturn {
  content: BeeHiveData[];
  totalPages: number;
  currentPage: number;
}

export interface BeeHivesQuery {
  page: number;
  size: number;
  frames?: number;
  queenValue?: string;
  hiveIdentifierValue?: string;
  medicationValue?: string;
  park?: string;
  foodBread?: boolean | '';
  foodSyrup?: boolean | '';
  order?: string[];
}

export interface BeeHiveCreate {
  id: number;
  hiveIdentifierValue: string;
  size: number;
  frames: number;
  framesOfBees: number;
  honey: number;
  newBroot: number;
  olderBroot: number;
  empty: number;
  queen: boolean;
  queenValue: QueenValueType;
  breed: BreedType;
  swarming: boolean;
  food: boolean;
  foodValue: FoodType;
  medications: boolean;
  medicationValue: MedicationType;
  activeStatus: boolean;
  notes: string;
  park: {
    id: number;
  };
}

export interface HivesForSessionReturn {
  id: number;
  hiveIdentifierValue: string;
  updatedForTheSession: boolean;
}
