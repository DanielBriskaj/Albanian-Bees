import { BeeHiveData } from './BeeHive';
import { ParkData } from './Park';

export interface HiveTransferCreate {
  fromParkId: number;
  toParkId: number;
  beeHiveToTransferId: number;
  description: string;
  createdAt: string;
}

export interface HiveTransferData {
  id: number;
  fromPark: ParkData;
  toPark: ParkData;
  beeHiveToTransfer: BeeHiveData;
  description: string;
  createdAt: string;
}

export interface HiveTransferQuery {
  page: number;
  size: number;
  createdAt: string;
  fromPark: string;
  toPark: string;
  order?: string[];
}

export interface HiveTransferReturn {
  content: HiveTransferData[];
  currentPage: number;
  totalPages: number;
  totalItems: number;
}
