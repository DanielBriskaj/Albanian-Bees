export interface LoginData {
  username: string;
  password: string;
}

export type UserRoles = 'USER' | 'ADMIN';
export interface SignUpData {
  username: string;
  password: string;
  name: string;
  role: UserRoles;
  surname: string;
  active: boolean;
}

export interface UserData {
  username: string;
  name: string;
  role: UserRoles;
  surname: string;
  active: boolean;
}
