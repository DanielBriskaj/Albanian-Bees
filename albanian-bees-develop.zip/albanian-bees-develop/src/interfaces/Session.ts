import { UserData } from './Auth';
import { BeeHiveCreate } from './BeeHive';
import { ParkData } from './Park';
import { TeamMemberData } from './TeamMember';
import { Weather } from './Weather';

export type SmokerTypes = 'CARDBOX' | 'WOOD';
export type StatusTypes = 'INITIALIZED' | 'IN_PROGRESS' | 'COMPLETED';
export interface SessionData {
  id: number;
  name: string;
  park: ParkData;
  teamMember: TeamMemberData[];
  smoker: SmokerTypes;
  weather: Weather;
  createdAt: string;
  createdBy: UserData;
  sessionStatus: StatusTypes;
  totalOfBeeHives: number;
}

export interface SessionReturn {
  content: SessionData[];
  totalPages: number;
  currentPage: number;
}

export interface SessionQuery {
  page: number;
  size: number;
  park?: string;
  createdAt?: string;
  createdBy?: string;
  teamMember?: string;
  order?: string[];
}

export interface SessionBeeHiveDataCreate {
  isSession: boolean;
  processId: number;
  data: BeeHiveCreate;
}

export interface SessionBeeHiveDataQuery {
  page: number;
  size: number;
  type?: string;
  createdAt?: string;
  createdBy?: string;
  session?: string;
  transfer?: string;
  hiveIdentifierValue?: string;
  order?: string[];
}
