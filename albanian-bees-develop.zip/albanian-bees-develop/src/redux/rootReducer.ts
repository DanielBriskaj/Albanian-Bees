import { combineReducers } from '@reduxjs/toolkit';
import { authApi } from './slices/auth/authApi';
import { parkApi } from './slices/park/parkApi';
import { teamMemberApi } from './slices/teamMember/teamMemberApi';
import { beeHiveApi } from './slices/beeHive/beeHiveApi';
import { sessionsApi } from './slices/sessions/sessionsApi';
import { weatherApi } from './slices/sessions/weatherApi';
import { beeHiveDataApi } from './slices/sessions/beeHiveDataApi';
import { transfersApi } from './slices/transfers/transfersApi';

const rootReducer = combineReducers({
  [authApi.reducerPath]: authApi.reducer,
  [parkApi.reducerPath]: parkApi.reducer,
  [teamMemberApi.reducerPath]: teamMemberApi.reducer,
  [beeHiveApi.reducerPath]: beeHiveApi.reducer,
  [sessionsApi.reducerPath]: sessionsApi.reducer,
  [weatherApi.reducerPath]: weatherApi.reducer,
  [beeHiveDataApi.reducerPath]: beeHiveDataApi.reducer,
  [transfersApi.reducerPath]: transfersApi.reducer,
});

export default rootReducer;
