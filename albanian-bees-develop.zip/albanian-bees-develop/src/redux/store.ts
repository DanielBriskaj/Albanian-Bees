import { configureStore, ThunkAction, Action } from '@reduxjs/toolkit';
import { rtkQueryErrorLogger } from './errorLogger';
import rootReducer from './rootReducer';
import { authApi } from './slices/auth/authApi';
import { beeHiveApi } from './slices/beeHive/beeHiveApi';
import { parkApi } from './slices/park/parkApi';
import { beeHiveDataApi } from './slices/sessions/beeHiveDataApi';
import { sessionsApi } from './slices/sessions/sessionsApi';
import { weatherApi } from './slices/sessions/weatherApi';
import { teamMemberApi } from './slices/teamMember/teamMemberApi';
import { transfersApi } from './slices/transfers/transfersApi';

export const store = configureStore({
  reducer: rootReducer,
  middleware: getDefaultMiddleware =>
    getDefaultMiddleware({
      serializableCheck: false,
    }).concat(
      authApi.middleware,
      parkApi.middleware,
      teamMemberApi.middleware,
      beeHiveApi.middleware,
      beeHiveDataApi.middleware,
      sessionsApi.middleware,
      weatherApi.middleware,
      transfersApi.middleware,
      rtkQueryErrorLogger,
    ),
});

export type AppDispatch = typeof store.dispatch;
export type RootState = ReturnType<typeof store.getState>;
export type AppThunk<ReturnType = void> = ThunkAction<
  ReturnType,
  RootState,
  unknown,
  Action<string>
>;
