import getConfig from '../../../helpers/config';
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { ParkData } from '../../../interfaces/Park';

const config = getConfig();

const { test } = config;

export const parkApi = createApi({
  reducerPath: 'park',
  baseQuery: fetchBaseQuery({
    baseUrl: test.baseUrl + `/park`,
    prepareHeaders(headers) {
      const token = localStorage.getItem('idToken');
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      return headers;
    },
  }),
  tagTypes: ['Park', 'GetAllParks'],
  endpoints: builder => ({
    createPark: builder.mutation<ParkData, ParkData>({
      query: data => ({
        url: `/create`,
        method: 'POST',
        body: data,
      }),
      invalidatesTags: ['GetAllParks'],
    }),
    updatePark: builder.mutation<ParkData, { id: number; data: ParkData }>({
      query: args => ({
        url: `/update/${args?.id}`,
        method: 'PUT',
        body: args?.data,
      }),
      invalidatesTags: ['Park', 'GetAllParks'],
    }),
    deletePark: builder.mutation<string, number>({
      query: id => ({
        url: `/delete/${id}`,
        method: 'DELETE',
      }),
      invalidatesTags: ['GetAllParks'],
    }),
    getAllParks: builder.query<ParkData[], void>({
      query: () => ({
        url: `/all`,
        method: 'GET',
      }),
      providesTags: ['GetAllParks'],
    }),
    getSinglePark: builder.query<ParkData, number>({
      query: id => ({
        url: `/${id}`,
        method: 'GET',
      }),
      providesTags: ['Park'],
    }),
  }),
});

export const {
  useCreateParkMutation,
  useUpdateParkMutation,
  useDeleteParkMutation,
  useGetAllParksQuery,
  useGetSingleParkQuery,
  useLazyGetAllParksQuery,
  useLazyGetSingleParkQuery,
} = parkApi;
