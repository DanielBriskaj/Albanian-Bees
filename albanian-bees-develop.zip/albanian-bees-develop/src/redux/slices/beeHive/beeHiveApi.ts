import getConfig from '../../../helpers/config';
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import {
  BeeHiveCreate,
  BeeHiveData,
  BeeHivesQuery,
  BeeHivesReturn,
  HivesForSessionReturn,
} from '../../../interfaces/BeeHive';
import { myPrepareSearchParams } from '../../../helpers/searchParams';

const config = getConfig();

const { test } = config;

export const beeHiveApi = createApi({
  reducerPath: 'bee_hive',
  baseQuery: fetchBaseQuery({
    baseUrl: test.baseUrl + `/bee_hive`,
    prepareHeaders(headers) {
      const token = localStorage.getItem('idToken');
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      return headers;
    },
  }),
  tagTypes: ['Hive', 'GetAllHives', 'SessionHives'],
  endpoints: builder => ({
    createHive: builder.mutation<BeeHiveData, BeeHiveCreate>({
      query: data => ({
        url: `/create`,
        method: 'POST',
        body: data,
      }),
      invalidatesTags: ['GetAllHives'],
    }),
    updateHive: builder.mutation<
      BeeHiveData,
      { id: number; data: BeeHiveCreate }
    >({
      query: args => ({
        url: `/update/${args?.id}`,
        method: 'PUT',
        body: args?.data,
      }),
      invalidatesTags: ['Hive'],
    }),
    deleteHive: builder.mutation<string, number>({
      query: id => ({
        url: `/delete/${id}`,
        method: 'DELETE',
      }),
    }),
    getAllHives: builder.query<BeeHivesReturn, BeeHivesQuery>({
      query: queryParams => ({
        url: `/all${myPrepareSearchParams(queryParams)}`,
        method: 'GET',
      }),
      providesTags: ['GetAllHives'],
    }),
    getSingleHive: builder.query<BeeHiveData, number>({
      query: id => ({
        url: `/${id}`,
        method: 'GET',
      }),
      providesTags: ['Hive'],
    }),
    getHivesForSession: builder.query<HivesForSessionReturn[], number>({
      query: id => ({
        url: `/get_for_session/${id}`,
        method: 'GET',
      }),
      providesTags: ['SessionHives'],
    }),
  }),
});

export const {
  useCreateHiveMutation,
  useDeleteHiveMutation,
  useGetAllHivesQuery,
  useGetSingleHiveQuery,
  useLazyGetAllHivesQuery,
  useLazyGetSingleHiveQuery,
  useUpdateHiveMutation,
  useGetHivesForSessionQuery,
  useLazyGetHivesForSessionQuery,
} = beeHiveApi;
