import getConfig from '../../../helpers/config';
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { TeamMemberData } from '../../../interfaces/TeamMember';

const config = getConfig();

const { test } = config;

export const teamMemberApi = createApi({
  reducerPath: 'team_member',
  baseQuery: fetchBaseQuery({
    baseUrl: test.baseUrl + `/team_member`,
    prepareHeaders(headers) {
      const token = localStorage.getItem('idToken');
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      return headers;
    },
  }),
  tagTypes: ['Member', 'GetAllMembers'],
  endpoints: builder => ({
    createMember: builder.mutation<TeamMemberData, TeamMemberData>({
      query: data => ({
        url: `/create`,
        method: 'POST',
        body: data,
      }),
      invalidatesTags: ['GetAllMembers'],
    }),
    updateMember: builder.mutation<
      TeamMemberData,
      { id: number; data: TeamMemberData }
    >({
      query: args => ({
        url: `/update/${args?.id}`,
        method: 'PUT',
        body: args?.data,
      }),
      invalidatesTags: ['Member', 'GetAllMembers'],
    }),
    deleteMember: builder.mutation<string, number>({
      query: id => ({
        url: `/delete/${id}`,
        method: 'DELETE',
      }),
      invalidatesTags: ['GetAllMembers'],
    }),
    getAllMembers: builder.query<TeamMemberData[], void>({
      query: () => ({
        url: `/all`,
        method: 'GET',
      }),
      providesTags: ['GetAllMembers'],
    }),
    getSingleMember: builder.query<TeamMemberData, number>({
      query: id => ({
        url: `/${id}`,
        method: 'GET',
      }),
      providesTags: ['Member'],
    }),
  }),
});

export const {
  useCreateMemberMutation,
  useDeleteMemberMutation,
  useGetAllMembersQuery,
  useGetSingleMemberQuery,
  useLazyGetAllMembersQuery,
  useLazyGetSingleMemberQuery,
  useUpdateMemberMutation,
} = teamMemberApi;
