import getConfig from '../../../helpers/config';
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import {
  HiveTransferCreate,
  HiveTransferData,
  HiveTransferQuery,
  HiveTransferReturn,
} from '../../../interfaces/Transfers';
import { myPrepareSearchParams } from '../../../helpers/searchParams';

const config = getConfig();

const { test } = config;

export const transfersApi = createApi({
  reducerPath: 'transfers',
  baseQuery: fetchBaseQuery({
    baseUrl: test.baseUrl + `/transfer`,
    prepareHeaders(headers) {
      const token = localStorage.getItem('idToken');
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      return headers;
    },
  }),
  tagTypes: ['GetTransfers'],
  endpoints: builder => ({
    transferHives: builder.mutation<HiveTransferData, HiveTransferCreate>({
      query: data => ({
        url: `/create_for_beehive`,
        method: 'POST',
        body: data,
      }),
      invalidatesTags: ['GetTransfers'],
    }),
    getTransfers: builder.query<HiveTransferReturn, HiveTransferQuery>({
      query: queryParams => ({
        url: `/all${myPrepareSearchParams(queryParams)}`,
        method: 'GET',
      }),
      providesTags: ['GetTransfers'],
    }),
  }),
});

export const {
  useTransferHivesMutation,
  useGetTransfersQuery,
  useLazyGetTransfersQuery,
} = transfersApi;
