import getConfig from '../../../helpers/config';
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { WeatherReturn } from '../../../interfaces/Weather';

const config = getConfig();

const { test } = config;

export const weatherApi = createApi({
  reducerPath: 'weather',
  baseQuery: fetchBaseQuery({
    baseUrl: test.baseUrl + `/weather`,
    prepareHeaders(headers) {
      const token = localStorage.getItem('idToken');
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      return headers;
    },
  }),
  tagTypes: ['GetWeather'],
  endpoints: builder => ({
    getWeather: builder.query<WeatherReturn, { id: number }>({
      query: id => ({
        url: `/get_weather_forecast_for_park/${id}`,
        method: 'GET',
      }),
      providesTags: ['GetWeather'],
    }),
  }),
});

export const { useGetWeatherQuery, useLazyGetWeatherQuery } = weatherApi;
