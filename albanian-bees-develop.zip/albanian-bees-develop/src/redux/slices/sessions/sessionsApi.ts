import getConfig from '../../../helpers/config';
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { myPrepareSearchParams } from '../../../helpers/searchParams';
import {
  SessionData,
  SessionQuery,
  SessionReturn,
} from '../../../interfaces/Session';

const config = getConfig();

const { test } = config;

export const sessionsApi = createApi({
  reducerPath: 'session',
  baseQuery: fetchBaseQuery({
    baseUrl: test.baseUrl + `/session`,
    prepareHeaders(headers) {
      const token = localStorage.getItem('idToken');
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      return headers;
    },
  }),
  tagTypes: ['Session', 'GetAllSessions'],
  endpoints: builder => ({
    createSession: builder.mutation<SessionData, SessionData>({
      query: data => ({
        url: `/create`,
        method: 'POST',
        body: data,
      }),
      invalidatesTags: ['GetAllSessions'],
    }),
    finalizeSession: builder.mutation<SessionData, number>({
      query: id => ({
        url: `/update/finalize/${id}`,
        method: 'PUT',
      }),
      invalidatesTags: ['Session'],
    }),

    getAllSessions: builder.query<SessionReturn, SessionQuery>({
      query: queryParams => ({
        url: `/all${myPrepareSearchParams(queryParams)}`,
        method: 'GET',
      }),
      providesTags: ['GetAllSessions'],
    }),
    getSingleSession: builder.query<SessionData, number>({
      query: id => ({
        url: `/${id}`,
        method: 'GET',
      }),
      providesTags: ['Session'],
    }),
  }),
});

export const {
  useCreateSessionMutation,
  useGetAllSessionsQuery,
  useLazyGetAllSessionsQuery,
  useGetSingleSessionQuery,
  useLazyGetSingleSessionQuery,
  useFinalizeSessionMutation,
} = sessionsApi;
