import getConfig from '../../../helpers/config';
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { myPrepareSearchParams } from '../../../helpers/searchParams';
import {
  SessionBeeHiveDataCreate,
  SessionBeeHiveDataQuery,
  SessionReturn,
} from '../../../interfaces/Session';
import { BeeHiveCreate, BeeHiveData } from '../../../interfaces/BeeHive';

const config = getConfig();

const { test } = config;

export const beeHiveDataApi = createApi({
  reducerPath: 'bee_hive_data',
  baseQuery: fetchBaseQuery({
    baseUrl: test.baseUrl + `/bee_hive_data`,
    prepareHeaders(headers) {
      const token = localStorage.getItem('idToken');
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      return headers;
    },
  }),
  tagTypes: ['GetAllSessionHiveData', 'SingleSessionHiveData'],
  endpoints: builder => ({
    createSessionHiveData: builder.mutation<
      BeeHiveData,
      SessionBeeHiveDataCreate
    >({
      query: ({ data, isSession, processId }) => ({
        url: `/create${myPrepareSearchParams({ isSession, processId })}`,
        method: 'POST',
        body: data,
      }),
      invalidatesTags: ['GetAllSessionHiveData'],
    }),

    updateSessionHiveData: builder.mutation<
      BeeHiveData,
      { data: BeeHiveCreate; beeHiveDataId: number }
    >({
      query: ({ data, beeHiveDataId }) => ({
        url: `/update/${beeHiveDataId}`,
        method: 'PUT',
        body: data,
      }),
      invalidatesTags: ['SingleSessionHiveData'],
    }),

    getAllSessionHiveData: builder.query<
      SessionReturn,
      SessionBeeHiveDataQuery
    >({
      query: queryParams => ({
        url: `/all${myPrepareSearchParams(queryParams)}`,
        method: 'GET',
      }),
      providesTags: ['GetAllSessionHiveData'],
    }),

    getSingleSessionHiveData: builder.query<
      BeeHiveData,
      { beeHiveId: number; sessionId: number }
    >({
      query: ({ beeHiveId, sessionId }) => ({
        url: `/${beeHiveId}/${sessionId}`,
        method: 'GET',
      }),
      providesTags: ['SingleSessionHiveData'],
    }),
  }),
});

export const {
  useCreateSessionHiveDataMutation,
  useGetAllSessionHiveDataQuery,
  useLazyGetAllSessionHiveDataQuery,
  useGetSingleSessionHiveDataQuery,
  useLazyGetSingleSessionHiveDataQuery,
  useUpdateSessionHiveDataMutation,
} = beeHiveDataApi;
