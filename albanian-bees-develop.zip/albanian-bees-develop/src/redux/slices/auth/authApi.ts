import getConfig from '../../../helpers/config';
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { LoginData, SignUpData } from '../../../interfaces/Auth';

const config = getConfig();

const { test } = config;

export const authApi = createApi({
  reducerPath: 'auth',
  baseQuery: fetchBaseQuery({
    baseUrl: test.baseUrl + `/auth`,
    prepareHeaders(headers) {
      const token = localStorage.getItem('idToken');
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      return headers;
    },
  }),
  tagTypes: ['User', 'GetAllUsers'],
  endpoints: builder => ({
    login: builder.mutation<{ jwt: string }, LoginData>({
      query: data => ({
        url: `/login`,
        method: 'POST',
        body: data,
      }),
      invalidatesTags: ['User'],
    }),
    signUp: builder.mutation<string, SignUpData>({
      query: data => ({
        url: `/signup`,
        method: 'POST',
        body: data,
      }),
    }),
  }),
});

export const { useLoginMutation, useSignUpMutation } = authApi;
